﻿Imports System.Data.OleDb

Module BD
    Dim conex As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=proyecto.accdb;Persist Security Info=False")

    Sub conecta()
        If conex.State = ConnectionState.Closed Then
            conex.Open()
        End If
    End Sub

    Sub desconecta()
        If conex.State = ConnectionState.Open Then
            conex.Close()
            conex.Dispose()
        End If
    End Sub
    Public ReadOnly Property consConex() As OleDbConnection
        Get
            Return conex
        End Get
    End Property

    Function obtDatAdapter(ByVal sel As String) As OleDbDataAdapter
        Dim daAdap As New OleDbDataAdapter(sel, conex)
        Return daAdap
    End Function

    Function obtCommBuilder(ByVal data As OleDbDataAdapter) As OleDbCommandBuilder
        Dim commB As New OleDbCommandBuilder(data)
        Return commB
    End Function
End Module
