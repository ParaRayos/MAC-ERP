﻿Public Class ListadoProductos

    Private Sub ListadoProductos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim ds As New BDDataSet
        Dim ad As New BDDataSetTableAdapters.PRODUCTOSTableAdapter
        ad.Fill(ds.PRODUCTOS)
        Dim rpt As New informeProductos
        rpt.SetDataSource(ds)
        Me.visor.ReportSource = rpt
    End Sub
End Class