﻿Public Class frmLogin
    Private Sub frmLogin_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.lbLogin.Focus()
        conecta()
        If logORegi(consConex) = True Then
            NuevaEmpresa.Show()
            Me.Close()
        End If
    End Sub

    Private Sub tbUsu_GotFocus(sender As Object, e As System.EventArgs) Handles tbUsu.GotFocus
        conGFocusUsu(Me.tbUsu, "Introduce tu usuario o email.")
    End Sub

    Private Sub tbUsu_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles tbUsu.KeyPress, tbCon.KeyPress
        conTecl(e)
    End Sub

    Private Sub tbUsu_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles tbUsu.Validating
        conValiUsu(Me.tbUsu, "Introduce tu usuario o email.")
    End Sub

    Private Sub tbCon_GotFocus(sender As Object, e As System.EventArgs) Handles tbCon.GotFocus
        conGFocusCont(Me.tbCon, "Introduce tu contraseña.")
    End Sub

    Private Sub tbCon_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles tbCon.Validating
        conValiCont(Me.tbCon, Me.btLogin, "Introduce tu contraseña.")
        checkMostarCon(Me.tbCon, Me.cbCon)
    End Sub

    Private Sub btLogin_Click(sender As System.Object, e As System.EventArgs) Handles btLogin.Click
        If validarDatos(Me.tbUsu.Text, Me.tbCon.Text) = True Then
            If login(consConex, Me.tbUsu.Text, Me.tbCon.Text) = True Then
                lanMenu(Me.rbSDI, Me)
            End If
        End If
    End Sub

    Private Sub cbCon_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbCon.CheckedChanged
        checkMostarCon(Me.tbCon, Me.cbCon)
    End Sub

    Private Sub lbReg_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbReg.LinkClicked
        NuevaEmpresa.Show()
        Me.Close()
    End Sub

    Private Sub llCamCon_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llCamCon.LinkClicked
        CamConLog.ShowDialog()
    End Sub

    Private Sub lbCer_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbCer.LinkClicked
        desconecta()
        Me.Close()
    End Sub

End Class
