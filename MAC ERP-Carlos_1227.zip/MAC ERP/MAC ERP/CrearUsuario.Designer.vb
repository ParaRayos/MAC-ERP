﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CrearUsuario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnFinalizar = New System.Windows.Forms.Button()
        Me.tbCon = New System.Windows.Forms.TextBox()
        Me.tbUsu = New System.Windows.Forms.TextBox()
        Me.tbRepCon = New System.Windows.Forms.TextBox()
        Me.tipoUsuario = New System.Windows.Forms.ComboBox()
        Me.lbAtras = New System.Windows.Forms.LinkLabel()
        Me.SuspendLayout()
        '
        'btnFinalizar
        '
        Me.btnFinalizar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFinalizar.Location = New System.Drawing.Point(141, 215)
        Me.btnFinalizar.Name = "btnFinalizar"
        Me.btnFinalizar.Size = New System.Drawing.Size(243, 27)
        Me.btnFinalizar.TabIndex = 4
        Me.btnFinalizar.Text = "Finalizar"
        Me.btnFinalizar.UseVisualStyleBackColor = True
        '
        'tbCon
        '
        Me.tbCon.ForeColor = System.Drawing.Color.DarkGray
        Me.tbCon.Location = New System.Drawing.Point(141, 130)
        Me.tbCon.MaxLength = 20
        Me.tbCon.Name = "tbCon"
        Me.tbCon.Size = New System.Drawing.Size(243, 20)
        Me.tbCon.TabIndex = 1
        Me.tbCon.Text = "Introduce la contraseña."
        '
        'tbUsu
        '
        Me.tbUsu.ForeColor = System.Drawing.Color.DarkGray
        Me.tbUsu.Location = New System.Drawing.Point(141, 98)
        Me.tbUsu.MaxLength = 15
        Me.tbUsu.Name = "tbUsu"
        Me.tbUsu.Size = New System.Drawing.Size(243, 20)
        Me.tbUsu.TabIndex = 0
        Me.tbUsu.Text = "Introduce el nick de usuario o email a registrar."
        '
        'tbRepCon
        '
        Me.tbRepCon.ForeColor = System.Drawing.Color.DarkGray
        Me.tbRepCon.Location = New System.Drawing.Point(141, 160)
        Me.tbRepCon.MaxLength = 20
        Me.tbRepCon.Name = "tbRepCon"
        Me.tbRepCon.Size = New System.Drawing.Size(243, 20)
        Me.tbRepCon.TabIndex = 2
        Me.tbRepCon.Text = "Repite la contraseña."
        '
        'tipoUsuario
        '
        Me.tipoUsuario.ForeColor = System.Drawing.Color.DarkGray
        Me.tipoUsuario.FormattingEnabled = True
        Me.tipoUsuario.Items.AddRange(New Object() {"Administrador", "Supervisor", "Empleado"})
        Me.tipoUsuario.Location = New System.Drawing.Point(141, 188)
        Me.tipoUsuario.Name = "tipoUsuario"
        Me.tipoUsuario.Size = New System.Drawing.Size(243, 21)
        Me.tipoUsuario.TabIndex = 3
        Me.tipoUsuario.Text = "Tipo de Usuario"
        '
        'lbAtras
        '
        Me.lbAtras.ActiveLinkColor = System.Drawing.Color.Blue
        Me.lbAtras.AutoSize = True
        Me.lbAtras.Location = New System.Drawing.Point(12, 351)
        Me.lbAtras.Name = "lbAtras"
        Me.lbAtras.Size = New System.Drawing.Size(34, 13)
        Me.lbAtras.TabIndex = 11
        Me.lbAtras.TabStop = True
        Me.lbAtras.Text = "Atrás."
        Me.lbAtras.VisitedLinkColor = System.Drawing.Color.Blue
        '
        'CrearUsuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Honeydew
        Me.ClientSize = New System.Drawing.Size(539, 373)
        Me.Controls.Add(Me.lbAtras)
        Me.Controls.Add(Me.tipoUsuario)
        Me.Controls.Add(Me.tbRepCon)
        Me.Controls.Add(Me.btnFinalizar)
        Me.Controls.Add(Me.tbCon)
        Me.Controls.Add(Me.tbUsu)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CrearUsuario"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CrearUsuario"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnFinalizar As System.Windows.Forms.Button
    Friend WithEvents tbCon As System.Windows.Forms.TextBox
    Friend WithEvents tbUsu As System.Windows.Forms.TextBox
    Friend WithEvents tbRepCon As System.Windows.Forms.TextBox
    Friend WithEvents tipoUsuario As System.Windows.Forms.ComboBox
    Friend WithEvents lbAtras As System.Windows.Forms.LinkLabel
End Class
