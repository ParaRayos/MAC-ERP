﻿Imports System.Data.OleDb

Module Producto
    Private _codArticulo As String
    Private _cifEmpresa As String
    Private _nombreProducto As String
    Private _tipoProducto As String
    Private _descripcion As String
    Private _precio As Integer
    Private _divisa As String
    Private _existencias As Integer
    Private _rutaImagen As String

    Public Property CodArticulo() As String
        Get
            Return _codArticulo
        End Get
        Set(ByVal value As String)
            _codArticulo = value
        End Set
    End Property

    Public Property CifEmpresa() As String
        Get
            Return _cifEmpresa
        End Get
        Set(ByVal value As String)
            _cifEmpresa = value
        End Set
    End Property

    Public Property NombreProducto() As String
        Get
            Return _nombreProducto
        End Get
        Set(ByVal value As String)
            _nombreProducto = value
        End Set
    End Property

    Public Property TipoProducto() As String
        Get
            Return _tipoProducto
        End Get
        Set(ByVal value As String)
            _tipoProducto = value
        End Set
    End Property

    Public Property Descripcion() As String
        Get
            Return _descripcion
        End Get
        Set(ByVal value As String)
            _descripcion = value
        End Set
    End Property

    Public Property Precio() As Integer
        Get
            Return _precio
        End Get
        Set(ByVal value As Integer)
            _precio = value
        End Set
    End Property

    Public Property Divisa() As String
        Get
            Return _divisa
        End Get
        Set(ByVal value As String)
            _divisa = value
        End Set
    End Property

    Public Property Existencias() As Integer
        Get
            Return _existencias
        End Get
        Set(ByVal value As Integer)
            _existencias = value
        End Set
    End Property

    Public Property RutaImagen() As String
        Get
            Return _rutaImagen
        End Get
        Set(ByVal value As String)
            _rutaImagen = value
        End Set
    End Property

    Sub insPro(ByVal con As OleDbConnection)
        Dim sIns As String = "Insert Into Productos" +
        "(COD_ARTICULO,CIF_EMPRESA,NOMBRE,TIPO_PRODUCTO,DESCRIPCION,PRECIO,DIVISA,EXISTENCIAS,RUTA_IMAGEN)" +
        "Values ('" + _codArticulo + "','" + _cifEmpresa + "','" + _nombreProducto + "','" + _tipoProducto + "','" + _descripcion + "'," + CType(_precio, String) + ",'" + _divisa + "'," + CType(_existencias, String) + ",'" + _rutaImagen + "')"
        Dim com As New OleDbCommand(sIns, con)
        com.ExecuteNonQuery()
    End Sub
End Module
