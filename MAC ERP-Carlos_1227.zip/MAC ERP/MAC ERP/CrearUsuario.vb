﻿Imports System.Data.OleDb
Imports System.IO
Public Class CrearUsuario

    Private Sub tbUsu_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tbUsu.GotFocus
        conGFocusUsu(Me.tbUsu, "Introduce el nick de usuario o email a registrar.")
    End Sub

    Private Sub tbUsu_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbUsu.KeyPress, tbCon.KeyPress, tbRepCon.KeyPress
        conTecl(e)
    End Sub

    Private Sub lbAtras_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        Dim cm As New OleDbCommand("Delete * from empresa where cif = @cif", BD.consConex)
        cm.Parameters.Add("@cif", OleDbType.Char, 9).Value = Empresa.Cif
        cm.ExecuteNonQuery()
        File.Delete(Application.StartupPath + Empresa.RutaImagen)
        NuevaEmpresa.Show()
        Me.Close()
    End Sub
End Class