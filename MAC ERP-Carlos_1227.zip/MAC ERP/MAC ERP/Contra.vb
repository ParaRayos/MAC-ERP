﻿Imports System.Data.OleDb

Module Contra
    Sub cambConCheck(ByVal txt As TextBox)
        If txt.UseSystemPasswordChar = True Then
            txt.UseSystemPasswordChar = False
        ElseIf txt.UseSystemPasswordChar = False Then
            txt.UseSystemPasswordChar = True
        End If
    End Sub

    Sub cambContra(ByVal con As OleDbConnection, ByVal txtContraseñaAntigua As String, ByVal txtContraseñaNueva1 As String, ByVal txtContraseñaNueva2 As String, ByVal usu As String)
        If Not txtContraseñaAntigua.Equals(txtContraseñaNueva1) Then
            If txtContraseñaNueva1.Equals(txtContraseñaNueva2) Then
                Dim reg As UInt16
                Dim co As New OleDbCommand("Select count(*) from usuarios where UCase(nick)=@usu and password=@pass", con)
                co.Parameters.Add("@usu", OleDbType.Char, 15).Value = usu.ToUpper
                co.Parameters.Add("@pass", OleDbType.Char, 20).Value = txtContraseñaAntigua
                Dim dRead As OleDbDataReader = co.ExecuteReader()
                While dRead.Read()
                    reg = CType(dRead(0).ToString(), UInt16)
                End While
                dRead.Close()
                co.Dispose()
                If reg = 0 Then
                    MessageBox.Show("El usuario actual o la contraseña actual no es correcta.", "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    Dim comm As New OleDbCommand("update usuarios set [password] = @pass where UCase(nick) = @usu", con)
                    Try
                        comm.Parameters.Add("@pass", OleDbType.Char, 20).Value = txtContraseñaNueva1
                        comm.Parameters.Add("@usu", OleDbType.Char, 20).Value = usu.ToUpper
                        comm.ExecuteNonQuery()
                    Catch ode As Exception
                        MessageBox.Show(ode.StackTrace.ToString + ode.Message.ToString + "/ " + ode.Data.ToString)
                    End Try
                End If
            Else
                MessageBox.Show("Los campos de nueva contraseña y repita contraseña no coinciden.", "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Else
            MessageBox.Show("La contraseña nueva no puede ser igual a la antigua.", "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Sub borraCampos(ByVal txtContraseñaAntigua As TextBox, ByVal txtContraseñaNueva1 As TextBox, ByVal txtContraseñaNueva2 As TextBox, ByVal cb1 As CheckBox, ByVal cb2 As CheckBox, ByVal cb3 As CheckBox)
        txtContraseñaAntigua.Text = ""
        txtContraseñaNueva1.Text = ""
        txtContraseñaNueva2.Text = ""
        cb1.Checked = False
        cb2.Checked = False
        cb3.Checked = False
        txtContraseñaAntigua.BackColor = Color.White
        txtContraseñaNueva1.BackColor = Color.White
        txtContraseñaNueva2.BackColor = Color.White
    End Sub
End Module
