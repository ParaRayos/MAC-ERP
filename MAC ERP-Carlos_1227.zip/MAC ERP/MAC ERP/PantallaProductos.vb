﻿Imports System.Data.OleDb

Public Class PantallaProductos
    Dim numeroSelecciones As Double

    Private Sub btnAñadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAñadir.Click
        numeroSelecciones = DataGridView1.SelectedRows.Count
        If numeroSelecciones = 0 Then
            AñadirProducto.Show()
        Else
            MessageBox.Show("Tiene algún producto seleccionado. Quite la selección para poder añadir un nuevo producto.", "INFORMACION", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        numeroSelecciones = DataGridView1.SelectedRows.Count
        If numeroSelecciones = 1 Then
            MessageBox.Show("Se eliminarán el producto seleccionado. ¿Quiere continuar?.", "INFORMACION", MessageBoxButtons.OKCancel)
        ElseIf numeroSelecciones > 0 Then
            MessageBox.Show("Tiene más de un producto seleccionado.", "INFORMACION", MessageBoxButtons.OK)
        Else
            MessageBox.Show("No tiene ningún producto seleccionado", "INFORMACION", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        numeroSelecciones = DataGridView1.SelectedRows.Count
        If numeroSelecciones = 1 Then
            ModificarProducto.Show()
        ElseIf numeroSelecciones > 1 Then
            MessageBox.Show("Tiene más de un producto seleccionado.", "INFORMACION", MessageBoxButtons.OK)
        ElseIf numeroSelecciones = 0 Then
            MessageBox.Show("Seleccione algún producto para modificar.", "INFORMACION", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub PantallaProductos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cargarProductos(BD.consConex)
    End Sub

    Public Sub cargarProductos(ByVal conexion As OleDbConnection)
        Dim tablaProductos As New DataTable
        Dim adapProductos As New OleDbDataAdapter
        Dim comando As New OleDbCommand("Select * from Productos where cif = @cif", conexion)
        comando.Parameters.Add("@cif", OleDbType.Char, 9).Value = Empresa.Cif
        adapProductos.SelectCommand = comando
        adapProductos.Fill(tablaProductos)
        Me.DataGridView1.DataSource = tablaProductos
        comando.ExecuteNonQuery()
        comando.Dispose()
        adapProductos.Dispose()
    End Sub

    Private Sub btnFacturar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFacturar.Click
        ListadoProductos.Show()
    End Sub
End Class