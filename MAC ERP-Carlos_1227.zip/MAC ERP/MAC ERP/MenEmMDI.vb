﻿Public Class MenEmMDI

    Private Sub ProductosToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ProductosToolStripMenuItem.Click
        Dim pr As New PantallaProductos
        pr.MdiParent = Me
        pr.Show()
    End Sub

    Private Sub ComprasToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ComprasToolStripMenuItem.Click

    End Sub

    Private Sub CambiarContraseñaToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CambiarContraseñaToolStripMenuItem.Click

    End Sub

    Private Sub MenEmMDI_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class