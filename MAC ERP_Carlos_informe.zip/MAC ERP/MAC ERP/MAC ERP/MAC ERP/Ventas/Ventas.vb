﻿Imports System.Data.OleDb
Imports System.IO

Public Class Ventas

    Private Sub btnAñadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAñadir.Click
        insertarVenta.Show()
        Me.Close()
    End Sub
    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        borrarVentas.Show()
        Me.Close()
    End Sub
    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        actualizarVenta.Show()
        Me.Close()
    End Sub
    Private Sub btnFacturar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFacturar.Click
        informeVentas.Show()
        Me.Close()
    End Sub

    Private Sub Ventas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        pbLogo.Image = Image.FromFile(Path.Combine(Application.StartupPath, Empresa.RutaImagen.Remove(0, 1)))
        Dim tablaVentas As New DataTable
        Dim sql As String = "SELECT pedido, linea_pedido, fecha, id_articulo, cantidad, importe_total, comprador FROM " & tabla2
        adapVentas = New OleDbDataAdapter(sql, consConex)
        adapVentas.Fill(tablaVentas)
        Me.dgvVentas.DataSource = tablaVentas
        Me.txtNombreEmpresa.Text = Empresa.Nombre
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        MenuEmpresa.Show()
        Me.Close()
    End Sub

    Private Sub llSalir_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub
End Class