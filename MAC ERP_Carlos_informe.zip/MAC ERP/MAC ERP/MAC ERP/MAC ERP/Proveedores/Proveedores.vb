﻿Imports System.Data.OleDb

Public Class Proveedores

    Private Sub btnAñadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAñadir.Click
        insertarProveedor.Show()
        Me.Close()
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        borrarProveedor.Show()
        Me.Close()
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        actualizarProveedor.Show()
        Me.Close()
    End Sub

    Private Sub btnFacturar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFacturar.Click
        informeProveedores.Show()
    End Sub

    Private Sub Proveedores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim tablaproveedores As New DataTable
        Dim sql As String = "SELECT id_proveedor, nombre, apellidos, pais, empresa, particular, telefono_movil, telefono_fijo, email  FROM " & tabla4
        adapProveedores = New OleDbDataAdapter(sql, consConex)
        adapProveedores.Fill(tablaproveedores)
        Me.dgvProveedores.DataSource = tablaproveedores
        Me.txtNombreEmpresa.Text = Empresa.Nombre
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        MenuEmpresa.Show()
        Me.Close()
    End Sub

    Private Sub llSalir_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub
End Class