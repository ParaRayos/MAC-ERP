﻿Imports System.Data.OleDb

Public Class informeClientes
    Private Sub informeClientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dataSetAlmacen = New DataSet
        dataSetAlmacen.Clear()
        Dim sql As String = "SELECT * FROM clientes WHERE cif_empresa = '" & Empresa.Cif & "'"

        adapClientes = New OleDbDataAdapter(sql, consConex)

        adapClientes.Fill(dataSetAlmacen, tabla3)

        Dim rpt As New informeCliente
        rpt.SetDataSource(dataSetAlmacen)
        Me.visor.ReportSource = rpt
    End Sub

    Private Sub ListadoProductos_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        PantallaProductos.Show()
    End Sub
End Class