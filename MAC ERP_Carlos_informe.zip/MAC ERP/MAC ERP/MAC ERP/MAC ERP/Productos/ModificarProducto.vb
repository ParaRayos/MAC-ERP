﻿Imports System.IO
Imports System.Data.OleDb

Public Class ModificarProducto
    Dim openFileDialog1 As New OpenFileDialog()
    Dim clipText As String
    Dim cambIm As Boolean = False
    Private Sub ModificarProducto_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        Me.txtCodigo.Text = Producto.CodArticulo
        Me.txtNombre.Text = Producto.NombreProducto
        Me.txtDescripcion.Text = Producto.Descripcion
        Me.txtDivisa.Text = Producto.Divisa
        Me.txtExistencia.Text = CStr(Producto.Existencias)
        Me.txtPrecio.Text = CStr(Producto.Precio)
        Me.txtTipo.Text = Producto.TipoProducto
        Dim ruta = Path.Combine(Application.StartupPath, Producto.RutaImagen.Remove(0, 1))
        MessageBox.Show(Producto.RutaImagen)
        Me.pbLogo.Image = Image.FromFile(ruta)
    End Sub

    Private Sub llSalir_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub

    Private Sub lbAtras_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        PantallaProductos.Show()
        Me.Close()
    End Sub

    Private Sub pbLogo_Click(sender As System.Object, e As System.EventArgs) Handles pbLogo.Click
        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "Archivos jpeg (*.jpeg)|*.jpeg|Todos los archivos (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            If openFileDialog1.FileName <> "" Then
                pbLogo.Image = Image.FromFile(openFileDialog1.FileName)
                cambIm = True
            End If
        End If
    End Sub

    Private Sub btnGuardarCambios_Click(sender As System.Object, e As System.EventArgs) Handles btnGuardarCambios.Click
        guardaCambios(txtCodigo.Text, txtNombre.Text, txtDescripcion.Text, txtTipo.Text, CType(txtPrecio.Text, Double), CInt(txtExistencia.Text), txtDivisa.Text, "\Imagenes\Productos\" + openFileDialog1.SafeFileName)
    End Sub

    Sub guardaCambios(ByVal cod As String, ByVal nom As String, ByVal desc As String, ByVal tipo As String, ByVal pre As Double, ByVal ex As Integer, ByVal divisa As String, ByVal ruta As String)
        Dim cambios As Boolean = False
        If nom.Equals(Producto.NombreProducto) Then
            If desc.Equals(Producto.Descripcion) Then
                If tipo.Equals(Producto.TipoProducto) Then
                    If pre = Producto.Precio Then
                        If ex = Producto.Existencias Then
                            If divisa.Equals(Producto.Divisa) Then
                                If ruta.Equals(Producto.RutaImagen) Or ruta.Equals("\Imagenes\Productos\") Then
                                Else
                                    cambios = True
                                End If
                            Else
                                cambios = True
                            End If
                        Else
                            cambios = True
                        End If
                    Else
                        cambios = True
                    End If
                Else
                    cambios = True
                End If
            Else
                cambios = True
            End If
        Else
            cambios = True
        End If

        If cambios Then
            Dim sql As String = "UPDATE productos SET nombre =?, tipo_producto =?, descripcion =?, precio =?, divisa =?, existencias =?, ruta_imagen =? WHERE cod_articulo = ? and cif_empresa = ?"
            Using actualizar = New OleDbCommand(sql, consConex)
                actualizar.Parameters.AddWithValue("@p1", txtNombre.Text)
                actualizar.Parameters.AddWithValue("@p2", txtTipo.Text)
                actualizar.Parameters.AddWithValue("@p3", txtDescripcion.Text)
                actualizar.Parameters.AddWithValue("@p4", Convert.ToDouble(txtPrecio.Text))
                actualizar.Parameters.AddWithValue("@p5", txtDivisa.Text)
                actualizar.Parameters.AddWithValue("@p6", Convert.ToInt32(txtExistencia.Text))
                Dim folder As String = Path.Combine(Application.StartupPath, "Imagenes\Productos")
                If cambIm Then
                    actualizar.Parameters.AddWithValue("@p7", "\Imagenes\Productos\" + openFileDialog1.SafeFileName)
                    guaIma(pbLogo, folder, openFileDialog1.SafeFileName)
                Else
                    actualizar.Parameters.AddWithValue("@p7", Producto.RutaImagen)
                    guaIma(pbLogo, folder, Producto.RutaImagen.Remove(0, 1))
                End If
                actualizar.Parameters.AddWithValue("@p8", txtCodigo.Text)
                actualizar.Parameters.AddWithValue("@p9", Empresa.Cif)
                actualizar.ExecuteNonQuery()
                MessageBox.Show("Modificación terminada correctamente", "Información:", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End Using
        Else
            MessageBox.Show("Los datos actuales son los mismos que al principio de la modificación.", "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Sub guaIma(ByVal pb As PictureBox, ByVal ru As String, ByVal arc As String)
        Dim fileName As String = ru + "\" + arc
        If System.IO.File.Exists(fileName) Then
            Dim arS() As String = Split(arc, CChar("."))
            arS(0) = arS(0) + "1"
            arc = arS(0) + "." + arS(1)
            guaIma(pb, ru, arc)
            Exit Sub
        Else
            Try
                pbLogo.Image.Save(fileName, System.Drawing.Imaging.ImageFormat.Jpeg)
            Catch ex As NullReferenceException
                arc = "MAC ERP.jpg"
            End Try
        End If
        Producto.RutaImagen = "\Imagenes\Productos\" + arc
    End Sub

    Private Sub txtExistencia_GotFocus(sender As Object, e As System.EventArgs) Handles txtExistencia.GotFocus, txtPrecio.GotFocus
        If Clipboard.ContainsText Then
            clipText = Clipboard.GetText
            Clipboard.Clear()
        End If
    End Sub

    Private Sub txtExistencia_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtExistencia.KeyPress
        If (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar)) Then

        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtPrecio_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtPrecio.KeyPress
        If (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or e.KeyChar = Chr(46)) Then

        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtExistencia_LostFocus(sender As Object, e As System.EventArgs) Handles txtExistencia.LostFocus, txtPrecio.LostFocus
        If Clipboard.ContainsText = False And Clipboard.ContainsImage = False And Clipboard.ContainsAudio = False And Clipboard.ContainsFileDropList = False Then
            Clipboard.SetText(clipText)
        End If
    End Sub
End Class