﻿Imports System.Data.OleDb
Imports System.IO

Public Class PantallaProductos
    Dim numeroSelecciones As Double

    Private Sub btnAñadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAñadir.Click
        numeroSelecciones = dgw.SelectedRows.Count
        If numeroSelecciones = 0 Then
            AñadirProducto.Show()
            Me.Close()
        Else
            MessageBox.Show("Tiene algún producto seleccionado. Quite la selección para poder añadir un nuevo producto.", "INFORMACION", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        numeroSelecciones = dgw.SelectedRows.Count
        If numeroSelecciones = 1 Then
            MessageBox.Show("Se eliminarán el producto seleccionado. ¿Quiere continuar?.", "INFORMACION", MessageBoxButtons.OKCancel)
            Dim comm As New OleDbCommand("Delete * from productos where cod_articulo = @art and cif_empresa = @cif", consConex)
            comm.Parameters.Add("@art", OleDbType.Char, 9).Value = dgw.CurrentRow.Cells(0).Value
            comm.Parameters.Add("@cif", OleDbType.Char, 9).Value = dgw.CurrentRow.Cells(1).Value
            comm.ExecuteNonQuery()
            cargarProductos(consConex)
        ElseIf numeroSelecciones > 0 Then
            MessageBox.Show("Tiene más de un producto seleccionado.", "INFORMACION", MessageBoxButtons.OK)
        Else
            MessageBox.Show("No tiene ningún producto seleccionado", "INFORMACION", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        numeroSelecciones = dgw.SelectedRows.Count
        If numeroSelecciones = 1 Then
            Producto.CodArticulo = CStr(Me.dgw.CurrentRow.Cells(0).Value)
            Producto.Descripcion = CStr(Me.dgw.CurrentRow.Cells(4).Value)
            Producto.Divisa = CStr(Me.dgw.CurrentRow.Cells(6).Value)
            Producto.Existencias = CInt(Me.dgw.CurrentRow.Cells(7).Value)
            Producto.NombreProducto = CStr(Me.dgw.CurrentRow.Cells(2).Value)
            Producto.Precio = CType(Me.dgw.CurrentRow.Cells(5).Value, Double)
            Producto.TipoProducto = CStr(Me.dgw.CurrentRow.Cells(3).Value)
            Producto.RutaImagen = CStr(Me.dgw.CurrentRow.Cells(8).Value)
            ModificarProducto.Show()
            Me.Close()
        ElseIf numeroSelecciones > 1 Then
            MessageBox.Show("Tiene más de un producto seleccionado.", "INFORMACION", MessageBoxButtons.OK)
        ElseIf numeroSelecciones = 0 Then
            MessageBox.Show("Seleccione algún producto para modificar.", "INFORMACION", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub PantallaProductos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cargarProductos(BD.consConex)
        Me.txtNombreEmpresa.Text = Empresa.Nombre
    End Sub

    Public Sub cargarProductos(ByVal conexion As OleDbConnection)
        Dim tablaProductos As New DataTable
        Dim adapProductos As New OleDbDataAdapter("Select * from Productos where cif_empresa = '" + Empresa.Cif + "'", conexion)
        adapProductos.Fill(tablaProductos)
        Me.dgw.DataSource = tablaProductos
        adapProductos.Dispose()
        tablaProductos.Dispose()
        cargaImg()
    End Sub

    Private Sub btnFacturar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFacturar.Click
        ListadoProductos.Show()
        Me.Close()
    End Sub

    Sub cargaImg()
        Dim ruta As String = Application.StartupPath + CStr(dgw.CurrentRow.Cells("RUTA_IMAGEN").Value)
        If File.Exists(ruta) Then
            pbLogo.Image = Image.FromFile(ruta)
        Else
            pbLogo.Image = Image.FromFile(Path.Combine(Application.StartupPath, "Imagenes\Productos\MAC ERP.jpg"))
            Dim com As New OleDbCommand("Update productos set [ruta_imagen]=@ruta where cif_empresa=@cif and cod_articulo=@art", consConex)
            com.Parameters.Add("@ruta", OleDbType.Char, 100).Value = "\Imagenes\Productos\MAC ERP.jpg"
            com.Parameters.Add("@cif", OleDbType.Char, 9).Value = Empresa.Cif
            com.Parameters.Add("@art", OleDbType.Char, 100).Value = CStr(Me.dgw.CurrentRow.Cells(0).Value)
            com.ExecuteNonQuery()
        End If
    End Sub

    Private Sub dgw_Click(sender As Object, e As System.EventArgs) Handles dgw.Click
        cargaImg()
    End Sub

    Private Sub lbAtras_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        MenuEmpresa.Show()
        Me.Close()
    End Sub

    Private Sub llSalir_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub
End Class