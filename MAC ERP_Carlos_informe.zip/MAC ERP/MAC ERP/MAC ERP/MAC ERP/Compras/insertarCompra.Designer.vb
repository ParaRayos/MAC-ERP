﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class insertarCompra
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(insertarCompra))
        Me.txtPedido = New System.Windows.Forms.MaskedTextBox()
        Me.txtLineaPedido = New System.Windows.Forms.MaskedTextBox()
        Me.txtIdArticulo = New System.Windows.Forms.MaskedTextBox()
        Me.txtCantidad = New System.Windows.Forms.MaskedTextBox()
        Me.txtFecha = New System.Windows.Forms.DateTimePicker()
        Me.txtImporteTotal = New System.Windows.Forms.MaskedTextBox()
        Me.txtVendedor = New System.Windows.Forms.MaskedTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnValidar = New System.Windows.Forms.Button()
        Me.btnValidar2 = New System.Windows.Forms.Button()
        Me.btnInsertar = New System.Windows.Forms.Button()
        Me.lbAtras = New System.Windows.Forms.LinkLabel()
        Me.SuspendLayout()
        '
        'txtPedido
        '
        Me.txtPedido.Location = New System.Drawing.Point(93, 79)
        Me.txtPedido.Mask = "999999"
        Me.txtPedido.Name = "txtPedido"
        Me.txtPedido.Size = New System.Drawing.Size(100, 20)
        Me.txtPedido.TabIndex = 0
        '
        'txtLineaPedido
        '
        Me.txtLineaPedido.Location = New System.Drawing.Point(93, 115)
        Me.txtLineaPedido.Mask = "999"
        Me.txtLineaPedido.Name = "txtLineaPedido"
        Me.txtLineaPedido.Size = New System.Drawing.Size(100, 20)
        Me.txtLineaPedido.TabIndex = 1
        '
        'txtIdArticulo
        '
        Me.txtIdArticulo.Enabled = False
        Me.txtIdArticulo.Location = New System.Drawing.Point(93, 151)
        Me.txtIdArticulo.Mask = "9999"
        Me.txtIdArticulo.Name = "txtIdArticulo"
        Me.txtIdArticulo.Size = New System.Drawing.Size(100, 20)
        Me.txtIdArticulo.TabIndex = 3
        '
        'txtCantidad
        '
        Me.txtCantidad.Enabled = False
        Me.txtCantidad.Location = New System.Drawing.Point(367, 115)
        Me.txtCantidad.Mask = "999"
        Me.txtCantidad.Name = "txtCantidad"
        Me.txtCantidad.Size = New System.Drawing.Size(100, 20)
        Me.txtCantidad.TabIndex = 6
        '
        'txtFecha
        '
        Me.txtFecha.Enabled = False
        Me.txtFecha.Location = New System.Drawing.Point(367, 75)
        Me.txtFecha.Name = "txtFecha"
        Me.txtFecha.Size = New System.Drawing.Size(200, 20)
        Me.txtFecha.TabIndex = 5
        '
        'txtImporteTotal
        '
        Me.txtImporteTotal.Enabled = False
        Me.txtImporteTotal.Location = New System.Drawing.Point(367, 151)
        Me.txtImporteTotal.Name = "txtImporteTotal"
        Me.txtImporteTotal.ReadOnly = True
        Me.txtImporteTotal.Size = New System.Drawing.Size(100, 20)
        Me.txtImporteTotal.TabIndex = 7
        '
        'txtVendedor
        '
        Me.txtVendedor.Enabled = False
        Me.txtVendedor.Location = New System.Drawing.Point(367, 187)
        Me.txtVendedor.Mask = "9999"
        Me.txtVendedor.Name = "txtVendedor"
        Me.txtVendedor.Size = New System.Drawing.Size(100, 20)
        Me.txtVendedor.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 82)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Pedido"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(21, 118)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 13)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Linea Pedido"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(295, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Fecha"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(21, 154)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 13)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "ID Artículo"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(295, 118)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Cantidad"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(295, 154)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Importe Total"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(295, 190)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Vendedor" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'btnValidar
        '
        Me.btnValidar.BackColor = System.Drawing.Color.Honeydew
        Me.btnValidar.Location = New System.Drawing.Point(212, 91)
        Me.btnValidar.Name = "btnValidar"
        Me.btnValidar.Size = New System.Drawing.Size(75, 23)
        Me.btnValidar.TabIndex = 2
        Me.btnValidar.Text = "Validar" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnValidar.UseVisualStyleBackColor = False
        '
        'btnValidar2
        '
        Me.btnValidar2.BackColor = System.Drawing.Color.Honeydew
        Me.btnValidar2.Location = New System.Drawing.Point(214, 151)
        Me.btnValidar2.Name = "btnValidar2"
        Me.btnValidar2.Size = New System.Drawing.Size(75, 23)
        Me.btnValidar2.TabIndex = 4
        Me.btnValidar2.Text = "Validar"
        Me.btnValidar2.UseVisualStyleBackColor = False
        Me.btnValidar2.Visible = False
        '
        'btnInsertar
        '
        Me.btnInsertar.BackColor = System.Drawing.Color.Honeydew
        Me.btnInsertar.Enabled = False
        Me.btnInsertar.Location = New System.Drawing.Point(262, 277)
        Me.btnInsertar.Name = "btnInsertar"
        Me.btnInsertar.Size = New System.Drawing.Size(75, 23)
        Me.btnInsertar.TabIndex = 9
        Me.btnInsertar.Text = "Insertar"
        Me.btnInsertar.UseVisualStyleBackColor = False
        '
        'lbAtras
        '
        Me.lbAtras.ActiveLinkColor = System.Drawing.Color.Blue
        Me.lbAtras.AutoSize = True
        Me.lbAtras.Location = New System.Drawing.Point(12, 365)
        Me.lbAtras.Name = "lbAtras"
        Me.lbAtras.Size = New System.Drawing.Size(31, 13)
        Me.lbAtras.TabIndex = 113
        Me.lbAtras.TabStop = True
        Me.lbAtras.Text = "Atrás"
        Me.lbAtras.VisitedLinkColor = System.Drawing.Color.Blue
        '
        'insertarCompra
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Honeydew
        Me.ClientSize = New System.Drawing.Size(575, 387)
        Me.Controls.Add(Me.lbAtras)
        Me.Controls.Add(Me.btnInsertar)
        Me.Controls.Add(Me.btnValidar2)
        Me.Controls.Add(Me.btnValidar)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtVendedor)
        Me.Controls.Add(Me.txtImporteTotal)
        Me.Controls.Add(Me.txtFecha)
        Me.Controls.Add(Me.txtCantidad)
        Me.Controls.Add(Me.txtIdArticulo)
        Me.Controls.Add(Me.txtLineaPedido)
        Me.Controls.Add(Me.txtPedido)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "insertarCompra"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Insertar"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtPedido As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtLineaPedido As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtIdArticulo As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtCantidad As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtImporteTotal As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtVendedor As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnValidar As System.Windows.Forms.Button
    Friend WithEvents btnValidar2 As System.Windows.Forms.Button
    Friend WithEvents btnInsertar As System.Windows.Forms.Button
    Friend WithEvents lbAtras As System.Windows.Forms.LinkLabel
End Class
