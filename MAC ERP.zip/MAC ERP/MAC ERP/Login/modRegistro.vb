﻿Imports System.Data.OleDb
Module modRegistro
    Sub conGFocusCont(ByVal camb As TextBox, ByVal texto As String)
        If camb.UseSystemPasswordChar = False And camb.Text.Equals(texto) Then
            camb.ForeColor = Color.Black
            camb.Text = ""
            camb.UseSystemPasswordChar = True
        End If
    End Sub

    Sub conValiCont(ByVal camb As TextBox, ByVal cam2 As Control, ByVal texto As String)
        If camb.Text.Equals("") Then
            cam2.Focus()
            camb.ForeColor = Color.DarkGray
            camb.UseSystemPasswordChar = False
            camb.Text = texto
        End If
    End Sub

    Sub conGFocusUsu(ByVal camb As TextBox, ByVal texto As String)
        If camb.Text.Equals(texto) Then
            camb.ForeColor = Color.Black
            camb.Text = ""
        End If
    End Sub

    Sub conValiUsu(ByVal camb As TextBox, ByVal texto As String)
        If camb.Text.Equals("") Then
            camb.ForeColor = Color.DarkGray
            camb.Text = texto
        End If
    End Sub
    Sub conTecl(ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If (Char.IsLetterOrDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or e.KeyChar = Chr(32)) And Not (e.KeyChar = Chr(34) Or e.KeyChar = Chr(39) Or e.KeyChar = Chr(61)) Then

        Else
            e.Handled = True
        End If
    End Sub

    Function validarDatos(ByVal Usuario As String, ByVal Contraseña As String) As Boolean
        Dim bo As Boolean = True
        Dim us As String = Usuario.ToUpper
        Dim co As String = Contraseña.ToUpper
        If us.Contains("(") Or us.Contains(")") Or us.Contains("'") Or us.Contains(Chr(34)) Or us.Contains(" LIKE") Or us.Contains(" AND") Or us.Contains("=") Or us.Contains(" IS") Or us.Contains(" IN") Or us.Contains("<") Or us.Contains(">") Or us.Contains(" EXISTS") Or us.Contains(" NOT") Or us.Contains(" BETWEEN") Then
            MessageBox.Show("No cuela")
            bo = False
        End If
        If co.Contains("(") Or co.Contains(")") Or co.Contains("'") Or co.Contains(Chr(34)) Or co.Contains(" LIKE") Or co.Contains(" AND") Or co.Contains("=") Or co.Contains(" IS") Or co.Contains(" IN") Or co.Contains("<") Or co.Contains(">") Or co.Contains(" EXISTS") Or co.Contains(" NOT") Or co.Contains(" BETWEEN") And bo = True Then
            MessageBox.Show("No cuela")
            bo = False
        End If
        Return bo
    End Function

    Function logORegi(ByVal con As OleDbConnection) As Boolean
        Dim registrar As Boolean = False
        Dim reg As UInt16
        Dim daAdap As New OleDbCommand("Select count(*) from usuarios", con)
        Dim dRead As OleDbDataReader = daAdap.ExecuteReader()
        While dRead.Read()
            reg = CType(dRead(0).ToString(), UInt16)
        End While
        dRead.Close()
        If reg = 0 Then
            registrar = True
        End If
        Return registrar
    End Function
    Sub checkMostarCon(ByVal tbCon As TextBox, ByVal check As CheckBox, ByVal men As String)
        If tbCon.Text.Equals(men) Then
            If check.Checked = True Then
                check.Checked = False
            End If
        Else
            If check.Checked = True Then
                tbCon.UseSystemPasswordChar = False
            Else
                tbCon.UseSystemPasswordChar = True
            End If
        End If
    End Sub

    Sub lanMenu(ByVal rad As RadioButton, ByVal form As Form)
        If rad.Checked = True Then
            MenuEmpresa.Show()
        Else
            MenEmMDI.Show()
        End If
        form.Close()
    End Sub

    Function login(ByVal con As OleDbConnection, ByVal user As String, ByVal contra As String) As Boolean
        Dim entra As Boolean = False
        Dim daAdap As New OleDbCommand("Select nick, password, cif_empresa, tipo_usuario from usuarios where UCase(nick) = @nick and password = @pass", con)
        daAdap.Parameters.Add("@nick", OleDbType.Char, 15).Value = user
        daAdap.Parameters.Add("@pass", OleDbType.Char, 20).Value = contra
        Dim dRead As OleDbDataReader = daAdap.ExecuteReader()
        While dRead.Read()
            Usuario.propNick = dRead.GetString(0)
            Usuario.propPass = dRead.GetString(1)
            Usuario.propCIFE = dRead.GetString(2)
            Usuario.propTipo = dRead.GetString(3)
        End While
        dRead.Close()
        daAdap.Dispose()
        Try
            If Not Usuario.propNick.Equals("") Then
                entra = True
                Dim em As New OleDbCommand("Select cif, nombre, localidad, provincia, pais, cod_postal, sector, ruta_imagen from empresa where cif = @cif", con)
                em.Parameters.Add("@cif", OleDbType.Char, 9).Value = Usuario.propCIFE
                Dim dr1 As OleDbDataReader = em.ExecuteReader()
                While dr1.Read()
                    Empresa.Cif = dr1.GetString(0)
                    Empresa.Nombre = dr1.GetString(1)
                    Empresa.Localidad = dr1.GetString(2)
                    Empresa.Provincia = dr1.GetString(3)
                    Empresa.Pais = dr1.GetString(4)
                    Empresa.CodPostal = dr1.GetString(5)
                    Empresa.Sector = dr1.GetString(6)
                    Try
                        Empresa.RutaImagen = dr1.GetString(7)
                    Catch ex As InvalidCastException
                        Empresa.RutaImagen = Nothing
                    End Try
                End While
                dr1.Close()
                em.Dispose()
            End If
        Catch nre As NullReferenceException
            MessageBox.Show("El usuario introducido o la contraseña introducida es incorrecta.", "Error al iniciar sesion:", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Return entra
    End Function
End Module
