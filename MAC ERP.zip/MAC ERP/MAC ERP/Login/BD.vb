﻿Imports System.Data.OleDb

Module BD
    Dim conex As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=proyecto.accdb;Persist Security Info=False")
    Dim inic As Integer = 0
    Public adapCompras As OleDbDataAdapter
    Public adapVentas As OleDbDataAdapter
    Public adapClientes As OleDbDataAdapter
    Public adapProveedores As OleDbDataAdapter
    Public dataSetAlmacen As DataSet
    Public comando As OleDbCommand
    Public bindingArticulos As New BindingSource
    Public bindingClientes As New BindingSource
    Public bindingPedidos As New BindingSource
    Public bindingProveedores As New BindingSource
    Public tabla0 As String = "PRODUCTOS"
    Public tabla1 As String = "COMPRA"
    Public tabla2 As String = "VENTA"
    Public tabla3 As String = "CLIENTES"
    Public tabla4 As String = "PROVEEDORES"
    Public tabla5 As String = "EMPRESA"

    Public Property inicio() As Integer
        Get
            Return inic
        End Get
        Set(ByVal value As Integer)
            inic = value
        End Set
    End Property

    Sub conecta()
        If conex.State = ConnectionState.Closed Then
            conex.Open()
        End If
    End Sub

    Sub desconecta()
        If conex.State = ConnectionState.Open Then
            conex.Close()
            conex.Dispose()
        End If
    End Sub
    Public ReadOnly Property consConex() As OleDbConnection
        Get
            Return conex
        End Get
    End Property

    Function obtDatAdapter(ByVal sel As String) As OleDbDataAdapter
        Dim daAdap As New OleDbDataAdapter(sel, conex)
        Return daAdap
    End Function

    Function obtCommBuilder(ByVal data As OleDbDataAdapter) As OleDbCommandBuilder
        Dim commB As New OleDbCommandBuilder(data)
        Return commB
    End Function
End Module
