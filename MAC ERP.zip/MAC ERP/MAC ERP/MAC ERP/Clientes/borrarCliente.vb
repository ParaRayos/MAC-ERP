﻿Option Strict On
Imports System.Data.OleDb

Public Class borrarCliente

    Public Sub enlazarDatos()
        bindingClientes.DataSource = dataSetAlmacen
        bindingClientes.DataMember = tabla3
        Me.txtNombre.DataBindings.Add(New Binding("Text", bindingClientes, "NOMBRE", True))
        Me.txtApellidos.DataBindings.Add(New Binding("Text", bindingClientes, "APELLIDOS", True))
        Me.txtDireccion.DataBindings.Add(New Binding("Text", bindingClientes, "DIRECCION", True))
        Me.txtLocalidad.DataBindings.Add(New Binding("Text", bindingClientes, "LOCALIDAD", True))
        Me.txtProvincia.DataBindings.Add(New Binding("Text", bindingClientes, "PROVINCIA", True))
        Me.txtPais.DataBindings.Add(New Binding("Text", bindingClientes, "PAIS", True))
        Me.txtEmpresa.DataBindings.Add(New Binding("Checked", bindingClientes, "EMPRESA", True))
        Me.txtParticular.DataBindings.Add(New Binding("Checked", bindingClientes, "PARTICULAR", True))
        Me.txtFijo.DataBindings.Add(New Binding("Text", bindingClientes, "TELEFONO_FIJO", True))
        Me.txtMovil.DataBindings.Add(New Binding("Text", bindingClientes, "TELEFONO_MOVIL", True))
        Me.txtEmail.DataBindings.Add(New Binding("Text", bindingClientes, "EMAIL", True))
    End Sub

    Sub buscar()
        Dim cliente As Integer
        Dim cif As String

        If txtCliente.Text = "" Or txtCif.Text = "" Then
            MessageBox.Show("Introduzca todos los datos por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select * from clientes where id_cliente =@cliente and cif = @cif", consConex)

            comando.Parameters.Add("@cliente", OleDbType.Integer, 4).Value = Me.txtCliente.Text
            comando.Parameters.Add("@cif", OleDbType.Char, 9).Value = Me.txtCif.Text

            adapClientes = New OleDbDataAdapter(comando)
            adapClientes.Fill(dataSetAlmacen, tabla3)

            Try
                Dim fila As DataRow
                Dim fila2 As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)
                fila2 = dataSetAlmacen.Tables(0).Rows(0)

                cliente = CInt(fila("ID_CLIENTE"))
                cif = CStr(fila2("CIF_EMPRESA"))

                Me.btnEliminar.Enabled = True
                Me.btnLimpiar.Enabled = True
                Me.btnBuscar.Visible = False
                Me.txtCliente.Enabled = False
                Me.txtCif.Enabled = False
                enlazarDatos()
            Catch ex As IndexOutOfRangeException
                MessageBox.Show("No existe ningún cliente con esos datos.")
            End Try
        End If
    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        buscar()
    End Sub

    Public Sub limpiar()
        Me.Close()
        Dim frm As New borrarCliente

        frm.Show()
    End Sub

    Sub eliminar()
        Dim eliminar As New OleDbCommand("DELETE FROM clientes WHERE id_cliente = @cliente AND cif = @cif", consConex)
        eliminar.Parameters.Add("@cliente", OleDbType.Integer, 4).Value = Me.txtCliente.Text
        eliminar.Parameters.Add("@cif", OleDbType.Char, 9).Value = txtCif.Text

        Dim j As Integer = eliminar.ExecuteNonQuery()
        If j > 0 Then
            MessageBox.Show("Cliente eliminado")
            limpiar()
        End If
    End Sub

    Private Sub btnLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        eliminar()
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked

        Clientes.Show()
        Me.Close()

    End Sub
End Class