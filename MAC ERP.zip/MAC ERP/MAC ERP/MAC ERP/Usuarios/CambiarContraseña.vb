﻿Public Class CambiarContraseña
    Dim llam As String
    Public Property llama() As String
        Get
            Return llam
        End Get
        Set(ByVal value As String)
            llam = value
        End Set
    End Property

    Private Sub cb1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb1.CheckedChanged
        cambConCheck(txtContraseñaAntigua)
    End Sub

    Private Sub cb2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb2.CheckedChanged
        cambConCheck(txtContraseñaNueva1)
    End Sub

    Private Sub cb3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb3.CheckedChanged
        cambConCheck(txtContraseñaNueva2)
    End Sub

    Private Sub btnBorrarCampos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrarCampos.Click
        Contra.borraCampos(txtContraseñaAntigua, txtContraseñaNueva1, txtContraseñaNueva2, cb1, cb2, cb3)
    End Sub

    Private Sub btnCambiarContraseña_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCambiarContraseña.Click

        If Contra.cambContra(BD.consConex, txtContraseñaAntigua.Text, txtContraseñaNueva1.Text, txtContraseñaNueva2.Text, Usuario.propNick) Then
            If llama = "SDI" Then
                MenuEmpresa.Show()
            End If
            Me.Close()
        End If
    End Sub
End Class