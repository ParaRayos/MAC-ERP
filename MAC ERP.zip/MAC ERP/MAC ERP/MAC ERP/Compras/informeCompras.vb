﻿Option Strict On
Imports System.Data.OleDb

Public Class informeCompras

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim desde As Date
        Dim hasta As Date

        desde = Convert.ToDateTime(txtDesde.Text)
        hasta = Convert.ToDateTime(txtHasta.Text)

        dataSetAlmacen = New DataSet
        dataSetAlmacen.Clear()


        Dim sql As String = "SELECT pedido, linea_pedido, fecha, id_articulo, cantidad, importe_total, vendedor FROM compra WHERE fecha >= #" & desde & "# and fecha <=#" & hasta & "#"

        adapCompras = New OleDbDataAdapter(sql, consConex)

        adapCompras.Fill(dataSetAlmacen, tabla1)

        Dim rpt As New informeCompra
        rpt.SetDataSource(dataSetAlmacen)
        Me.CrystalReportViewer1.ReportSource = rpt
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
    Private Sub txtHasta_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtHasta.ValueChanged

    End Sub
    Private Sub txtDesde_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDesde.ValueChanged

    End Sub
    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        Me.Close()
        Compras.Show()
    End Sub
End Class