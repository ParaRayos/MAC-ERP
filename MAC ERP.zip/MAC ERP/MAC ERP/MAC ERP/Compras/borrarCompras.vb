﻿Option Strict On
Imports System.Data.OleDb

Public Class borrarCompras

    Public Sub enlazarDatos()
        bindingCompras.DataSource = dataSetAlmacen
        bindingCompras.DataMember = tabla1
        Me.txtFecha.DataBindings.Add(New Binding("Text", bindingCompras, "FECHA", True))
        Me.txtIdArticulo.DataBindings.Add(New Binding("Text", bindingCompras, "ID_ARTICULO", True))
        Me.txtCantidad.DataBindings.Add(New Binding("Text", bindingCompras, "CANTIDAD", True))
        Me.txtImporteTotal.DataBindings.Add(New Binding("Text", bindingCompras, "IMPORTE_TOTAL", True))
        Me.txtVendedor.DataBindings.Add(New Binding("Text", bindingCompras, "VENDEDOR", True))
    End Sub

    Sub buscar()
        Dim pedido As Integer
        Dim linea_pedido As Integer

        If txtPedido.Text = "" Or txtLineaPedido.Text = "" Then
            MessageBox.Show("Introduzca todos los datos por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select * from compra where pedido =@pedido and linea_pedido = @linea", consConex)

            comando.Parameters.Add("@pedido", OleDbType.Integer, 6).Value = CInt(Me.txtPedido.Text())
            comando.Parameters.Add("@linea", OleDbType.Integer, 3).Value = txtLineaPedido.Text

            adapCompras = New OleDbDataAdapter(comando)
            adapCompras.Fill(dataSetAlmacen, tabla1)

            Try
                Dim fila As DataRow
                Dim fila2 As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)
                fila2 = dataSetAlmacen.Tables(0).Rows(0)

                pedido = CInt(fila("PEDIDO"))
                linea_pedido = CInt(fila2("LINEA_PEDIDO"))

                Me.btnEliminar.Enabled = True
                Me.btnLimpiar.Enabled = True
                Me.txtPedido.Enabled = False
                Me.txtLineaPedido.Enabled = False
                Me.btnBuscar.Visible = False
                enlazarDatos()
            Catch ex As IndexOutOfRangeException
                MessageBox.Show("No existe ninguna compra con esos datos.")
            End Try
        End If
    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        buscar()
    End Sub

    Public Sub limpiar()
        Me.Close()
        Dim frm As New borrarCompras

        frm.Show()
    End Sub

    Sub eliminar()
        Dim eliminar As New OleDbCommand("DELETE FROM compra WHERE pedido = @pedido AND linea_pedido = @linea", consConex)
        eliminar.Parameters.Add("@pedido", OleDbType.Integer, 6).Value = CInt(Me.txtPedido.Text())
        eliminar.Parameters.Add("@linea", OleDbType.Integer, 3).Value = txtLineaPedido.Text

        Dim j As Integer = eliminar.ExecuteNonQuery()
        If j > 0 Then
            MessageBox.Show("Compra eliminada")
            limpiar()
        End If
    End Sub

    Private Sub btnLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        eliminar()
    End Sub

    Private Sub borrarCompras_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtIdArticulo_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles txtIdArticulo.MaskInputRejected

    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        Compras.Show()
        Me.Close()

    End Sub
End Class