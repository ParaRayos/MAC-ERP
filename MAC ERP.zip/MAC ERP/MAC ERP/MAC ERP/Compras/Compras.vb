﻿Imports System.Data.OleDb
Imports System.IO

Public Class Compras

    Private Sub btnAñadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAñadir.Click
        insertarCompra.Show()
        Me.Close()
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        borrarCompras.Show()
        Me.Close()
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        actualizarCompra.Show()
        Me.Close()
    End Sub

    Private Sub btnFacturar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFacturar.Click
        informeCompras.Show()
    End Sub

    Private Sub Compras_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        pbLogo.Image = Image.FromFile(Path.Combine(Application.StartupPath, Empresa.RutaImagen.Remove(0, 1)))
        Dim tablaCompras As New DataTable
        Dim sql As String = "SELECT pedido, linea_pedido, fecha, id_articulo, cantidad, importe_total, vendedor FROM " & tabla1
        adapCompras = New OleDbDataAdapter(sql, consConex)
        adapCompras.Fill(tablaCompras)
        Me.dgvCompras.DataSource = tablaCompras
        Me.txtNombreEmpresa.Text = Empresa.Nombre
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        MenuEmpresa.Show()
        Me.Close()
    End Sub

    Private Sub llSalir_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub
End Class