﻿Option Strict On
Imports System.Data.OleDb

Public Class actualizarCompra

    Public Sub mostrar()
        txtFecha.Enabled = True
        txtCantidad.Enabled = True
        txtVendedor.Enabled = True
        btnActualizar.Enabled = True

        txtPedido.Enabled = False
        txtLineaPedido.Enabled = False
        btnBuscar.Visible = False
        btnValidar.Visible = False
    End Sub

    Public Sub ocultar()
        Me.txtFecha.Enabled = False
        Me.txtCantidad.Enabled = False
        Me.txtVendedor.Enabled = False
        btnActualizar.Enabled = False
    End Sub

    Public Sub enlazarDatos()
        bindingCompras.DataSource = dataSetAlmacen
        bindingCompras.DataMember = tabla1
        Me.txtFecha.DataBindings.Add(New Binding("Text", bindingCompras, "FECHA", True))
        Me.txtIdArticulo.DataBindings.Add(New Binding("Text", bindingCompras, "ID_ARTICULO", True))
        Me.txtCantidad.DataBindings.Add(New Binding("Text", bindingCompras, "CANTIDAD", True))
        Me.txtImporteTotal.DataBindings.Add(New Binding("Text", bindingCompras, "IMPORTE_TOTAL", True))
        Me.txtVendedor.DataBindings.Add(New Binding("Text", bindingCompras, "VENDEDOR", True))
    End Sub

    Sub buscar()
        Dim pedido As Integer
        Dim linea_pedido As Integer

        If txtPedido.Text = "" Or txtLineaPedido.Text = "" Then
            MessageBox.Show("Introduzca todos los datos por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select * from compra where pedido =@pedido and linea_pedido = @linea", consConex)

            comando.Parameters.Add("@pedido", OleDbType.Integer, 6).Value = CInt(Me.txtPedido.Text())
            comando.Parameters.Add("@linea", OleDbType.Integer, 3).Value = txtLineaPedido.Text

            adapCompras = New OleDbDataAdapter(comando)
            adapCompras.Fill(dataSetAlmacen, tabla1)

            Try
                Dim fila As DataRow
                Dim fila2 As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)
                fila2 = dataSetAlmacen.Tables(0).Rows(0)

                pedido = CInt(fila("PEDIDO"))
                linea_pedido = CInt(fila2("LINEA_PEDIDO"))

                Me.btnActualizar.Enabled = True
                Me.btnLimpiar.Enabled = True
                enlazarDatos()
                btnValidar.Visible = True
                txtIdArticulo.Enabled = True
                Me.txtPedido.Enabled = False
                Me.txtLineaPedido.Enabled = False
                Me.btnBuscar.Visible = False
            Catch ex As IndexOutOfRangeException
                MessageBox.Show("No existe ninguna compra con esos datos.")
            End Try
        End If
    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        buscar()
    End Sub

    Public Sub limpiar()
        Me.Close()
        Dim frm As New actualizarCompra

        frm.Show()
    End Sub

    Private Sub btnLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Public Function actualizarCantidad() As Integer
        Dim cantidad As Integer

        Dim sql As String = "SELECT cantidad from compra where pedido = ? and linea_pedido = ? "
        Using comando = New OleDbCommand(sql, consConex)
            comando.Parameters.AddWithValue("@p1", Convert.ToInt16(txtIdArticulo.Text))
            comando.Parameters.AddWithValue("@p2", Convert.ToInt16(txtLineaPedido.Text))
            cantidad = CInt(comando.ExecuteScalar())

        End Using
        cantidad = CInt(CDbl(txtCantidad.Text) - cantidad)

        Return cantidad

    End Function

    Public Sub actualizarExistenias()
        Dim existencias As Integer

        Dim sql As String = "SELECT existencias from productos where cod_articulo = ? and cif_empresa = '" & Empresa.Cif & "' "
        Using comando = New OleDbCommand(sql, consConex)
            comando.Parameters.AddWithValue("@p1", Convert.ToInt16(txtIdArticulo.Text))
            existencias = CInt(comando.ExecuteScalar())
        End Using

        existencias = CInt(existencias + actualizarCantidad())

        Dim sql2 As String = "UPDATE productos SET existencias =? WHERE cod_articulo = ? and cif_empresa = '" & Empresa.Cif & "'"
        Using act = New OleDbCommand(sql2, consConex)
            act.Parameters.AddWithValue("@p1", existencias)
            act.Parameters.AddWithValue("@p2", Convert.ToInt16(txtIdArticulo.Text))
            act.ExecuteNonQuery()
        End Using
    End Sub

    Public Sub actualizar()
        Dim sql As String = "UPDATE compra SET fecha =?, id_articulo =?, cantidad =?, importe_total =?, vendedor = ? WHERE pedido = ? and linea_pedido = ?"
        Using actualizar = New OleDbCommand(sql, consConex)
            actualizar.Parameters.AddWithValue("@p1", Convert.ToDateTime(txtFecha.Text))
            actualizar.Parameters.AddWithValue("@p2", Convert.ToInt16(txtIdArticulo.Text))
            actualizar.Parameters.AddWithValue("@p3", Convert.ToInt16(txtCantidad.Text))
            actualizar.Parameters.AddWithValue("@p4", Convert.ToDouble(txtImporteTotal.Text))
            actualizar.Parameters.AddWithValue("@p5", txtVendedor.Text)
            actualizar.Parameters.AddWithValue("@p6", Convert.ToInt16(txtPedido.Text))
            actualizar.Parameters.AddWithValue("@p7", Convert.ToInt16(txtLineaPedido.Text))

            actualizarCantidad()
            actualizarExistenias()

            actualizar.ExecuteNonQuery()

            MessageBox.Show("Compra actualizada")


        End Using
    End Sub

    Private Sub btnActualizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnActualizar.Click
        actualizar()
        limpiar()
    End Sub

    Private Sub txtCantidad_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtCantidad.Validating
        Dim precio As Double
        Dim importeTotal As Double
        Dim tablaProductos As New DataTable
        Dim sql As String = "SELECT precio from productos where cod_articulo = ? and cif_empresa = '" & Empresa.Cif & "' "
        Using comando = New OleDbCommand(sql, consConex)
            comando.Parameters.AddWithValue("@p1", Convert.ToInt16(txtIdArticulo.Text))
            precio = CDbl(comando.ExecuteScalar())
        End Using

        If txtCantidad.Text <> "" Then
            importeTotal = precio * CDbl(txtCantidad.Text)
            txtImporteTotal.Text = CStr(importeTotal)
        Else
            txtImporteTotal.Text = ""
        End If
    End Sub

    Public Sub validarArticulo()
        Dim articulo As Integer
        If txtIdArticulo.Text = "" Then
            MessageBox.Show("Introduzca el id del artículo por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select cod_articulo from productos where cod_articulo =@articulo ", consConex)

            comando.Parameters.Add("@articulo", OleDbType.Integer, 4).Value = Me.txtIdArticulo.Text

            adapCompras = New OleDbDataAdapter(comando)
            adapCompras.Fill(dataSetAlmacen, tabla0)

            Try
                Dim fila As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)

                articulo = CInt(fila("COD_ARTICULO"))

                mostrar()
            Catch ex As IndexOutOfRangeException
                MessageBox.Show("No existe ningún artículo con ese código.")
            End Try
        End If
    End Sub

    Private Sub btnValidar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValidar.Click
        validarArticulo()
    End Sub

    Private Sub txtIdArticulo_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtIdArticulo.TextChanged
        ocultar()
        btnValidar.Visible = True
    End Sub

    Private Sub actualizarCompra_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked

        Compras.Show()
        Me.Close()

    End Sub
End Class