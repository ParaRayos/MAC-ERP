﻿Imports System.Data.OleDb

Public Class ListadoProductos

    Private Sub ListadoProductos_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        PantallaProductos.Show()
    End Sub

    Private Sub ListadoProductos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim ds As New BDDataSet
        Dim con As OleDbConnection = consConex
        Dim ad As New OleDbDataAdapter("Select * from productos where cif_empresa ='" + Empresa.Cif + "'", con)
        Dim adD As New OleDbDataAdapter("Select * from empresa where cif ='" + Empresa.Cif + "'", con)
        ad.Fill(ds.PRODUCTOS)
        adD.Fill(ds.EMPRESA)
        Dim rpt As New informeProductos
        rpt.SetDataSource(ds)
        Me.visor.ReportSource = rpt
    End Sub
End Class