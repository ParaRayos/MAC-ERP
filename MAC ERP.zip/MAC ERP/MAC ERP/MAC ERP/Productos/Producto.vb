﻿Imports System.Data.OleDb

Module Producto
    Private _codArticulo As String
    Private _nombreProducto As String
    Private _tipoProducto As String
    Private _descripcion As String
    Private _precio As Double
    Private _divisa As String
    Private _existencias As Integer
    Private _rutaImagen As String

    Public Property CodArticulo() As String
        Get
            Return _codArticulo
        End Get
        Set(ByVal value As String)
            _codArticulo = value
        End Set
    End Property

    Public Property NombreProducto() As String
        Get
            Return _nombreProducto
        End Get
        Set(ByVal value As String)
            _nombreProducto = value
        End Set
    End Property

    Public Property TipoProducto() As String
        Get
            Return _tipoProducto
        End Get
        Set(ByVal value As String)
            _tipoProducto = value
        End Set
    End Property

    Public Property Descripcion() As String
        Get
            Return _descripcion
        End Get
        Set(ByVal value As String)
            _descripcion = value
        End Set
    End Property

    Public Property Precio() As Double
        Get
            Return _precio
        End Get
        Set(ByVal value As Double)
            _precio = value
        End Set
    End Property

    Public Property Divisa() As String
        Get
            Return _divisa
        End Get
        Set(ByVal value As String)
            _divisa = value
        End Set
    End Property

    Public Property Existencias() As Integer
        Get
            Return _existencias
        End Get
        Set(ByVal value As Integer)
            _existencias = value
        End Set
    End Property

    Public Property RutaImagen() As String
        Get
            Return _rutaImagen
        End Get
        Set(ByVal value As String)
            _rutaImagen = value
        End Set
    End Property

    Sub insPro(ByVal con As OleDbConnection)
        Dim insertar As New OleDbCommand("INSERT INTO Productos(COD_ARTICULO,CIF_EMPRESA,NOMBRE,TIPO_PRODUCTO,DESCRIPCION,PRECIO,DIVISA,EXISTENCIAS,RUTA_IMAGEN) values(@art, @cif, @nom, @tipo, @desc, @pre, @divisa, @exis, @ruta)", consConex)
        insertar.Parameters.Add("@art", OleDbType.Char, 9).Value = Producto.CodArticulo
        insertar.Parameters.Add("@cif", OleDbType.Char, 9).Value = Empresa.Cif
        insertar.Parameters.Add("@nom", OleDbType.Char, 25).Value = Producto.NombreProducto
        insertar.Parameters.Add("@tipo", OleDbType.Char, 20).Value = Producto.TipoProducto
        insertar.Parameters.Add("@desc", OleDbType.Char, 50).Value = Producto.Descripcion
        insertar.Parameters.Add("@pre", OleDbType.Double, 6).Value = Producto.Precio
        insertar.Parameters.Add("@divisa", OleDbType.Char, 10).Value = Producto.Divisa
        insertar.Parameters.Add("@exis", OleDbType.Integer, 4).Value = Producto.Existencias
        insertar.Parameters.Add("@ruta", OleDbType.Char, 100).Value = Producto.RutaImagen
        insertar.ExecuteNonQuery()
    End Sub
End Module
