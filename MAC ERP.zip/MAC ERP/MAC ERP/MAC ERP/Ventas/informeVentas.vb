﻿Imports System.Data.OleDb

Public Class informeVentas

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim desde As Date
        Dim hasta As Date

        desde = Convert.ToDateTime(txtDesde.Text)
        hasta = Convert.ToDateTime(txtHasta.Text)

        dataSetAlmacen = New DataSet
        dataSetAlmacen.Clear()


        Dim sql As String = "SELECT pedido, linea_pedido, fecha, id_articulo, cantidad, importe_total, comprador FROM venta WHERE fecha >= #" & desde & "# and fecha <=#" & hasta & "#"

        adapVentas = New OleDbDataAdapter(sql, consConex)

        adapVentas.Fill(dataSetAlmacen, tabla2)

        Dim rpt As New informeVenta
        rpt.SetDataSource(dataSetAlmacen)
        Me.CrystalReportViewer1.ReportSource = rpt
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked

        Ventas.Show()
        Me.Close()

    End Sub

    Private Sub llSalir_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub
End Class