﻿Imports System.Data.OleDb

Public Class informeClientes
    Dim borr As Boolean = False
    Public Property borrar() As Boolean
        Get
            Return borr
        End Get
        Set(ByVal value As Boolean)
            borr = value
        End Set
    End Property
    Private Sub informeClientes_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If borr = False Then
            Clientes.Show()
        End If
    End Sub
    Private Sub informeClientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dataSetAlmacen = New DataSet
        dataSetAlmacen.Clear()
        Dim sql As String = "SELECT * FROM clientes WHERE cif_empresa = '" & Empresa.Cif & "'"

        adapClientes = New OleDbDataAdapter(sql, consConex)

        adapClientes.Fill(dataSetAlmacen, tabla3)

        Dim rpt As New informeCliente
        rpt.SetDataSource(dataSetAlmacen)
        Me.CrystalReportViewer1.ReportSource = rpt
    End Sub

End Class