﻿Option Strict On
Imports System.Data.OleDb

Public Class insertarCliente
    Dim borr As Boolean = False
    Public Property borrar() As Boolean
        Get
            Return borr
        End Get
        Set(ByVal value As Boolean)
            borr = value
        End Set
    End Property
    Public Sub mostrar()
        txtCif.Enabled = True
        txtNombre.Enabled = True
        txtApellidos.Enabled = True
        txtDireccion.Enabled = True
        txtLocalidad.Enabled = True
        txtProvincia.Enabled = True
        txtPais.Enabled = True
        txtParticular.Enabled = True
        txtEmpresa.Enabled = True
        txtFijo.Enabled = True
        txtMovil.Enabled = True
        txtEmail.Enabled = True
        btnInsertar.Enabled = True
    End Sub

    Public Sub ocultar()
        txtCif.Enabled = False
        txtNombre.Enabled = False
        txtApellidos.Enabled = False
        txtDireccion.Enabled = False
        txtLocalidad.Enabled = False
        txtProvincia.Enabled = False
        txtPais.Enabled = False
        txtParticular.Enabled = False
        txtEmpresa.Enabled = False
        txtFijo.Enabled = False
        txtMovil.Enabled = False
        txtEmail.Enabled = False
        btnInsertar.Enabled = False
        btnValidar.Visible = True
    End Sub

    Public Sub limpiar()
        Me.txtCliente.Text = ""
        Me.txtCif.Text = ""
        Me.txtNombre.Text = ""
        Me.txtApellidos.Text = ""
        Me.txtLocalidad.Text = ""
        Me.txtProvincia.Text = ""
        Me.txtPais.Text = ""
        Me.txtDireccion.Text = ""
        Me.txtEmpresa.Text = ""
        Me.txtParticular.Text = ""
        Me.txtFijo.Text = ""
        Me.txtMovil.Text = ""
        Me.txtEmail.Text = ""
    End Sub

    Private Sub txtCliente_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCliente.TextChanged
        ocultar()
    End Sub

    Public Sub validarProveedor()
        Dim cliente As Integer
        Dim cif As String
        If txtCliente.Text = "" Then
            MessageBox.Show("Introduzca el id del cliente por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select * from clientes where id_cliente =@cliente and cif_empresa = @cif", consConex)

            comando.Parameters.Add("@cliente", OleDbType.Integer, 4).Value = Me.txtCliente.Text
            comando.Parameters.Add("@cif", OleDbType.Char, 9).Value = Empresa.Cif

            adapClientes = New OleDbDataAdapter(comando)
            adapClientes.Fill(dataSetAlmacen, tabla3)

            Try
                Dim fila As DataRow
                Dim fila2 As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)
                fila2 = dataSetAlmacen.Tables(0).Rows(0)

                cliente = CInt(fila("ID_CLIENTE"))
                cif = CStr(fila2("CIF_EMPRESA"))

                MessageBox.Show("Ya existe un cliente con esos datos.")
            Catch ex As IndexOutOfRangeException



                btnValidar.Visible = False
                mostrar()
            End Try
        End If
    End Sub

    Private Sub btnValidar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValidar.Click
        validarProveedor()
    End Sub

    Public Sub insertar()
        Try

       
        Dim insertar As New OleDbCommand("INSERT INTO clientes(id_cliente, cif_empresa, nombre, apellidos, direccion, localidad, provincia, pais, telefono_fijo, telefono_movil, email, cif) values(@cliente, @cif_empresa, @nombre, @apellidos, @direccion, @localidad, @provincia, @pais, @fijo, @movil, @email, @cif)", consConex)
        insertar.Parameters.Add("@cliente", OleDbType.Integer, 4).Value = CInt(Me.txtCliente.Text())
        insertar.Parameters.Add("@cif_empresa", OleDbType.Char, 9).Value = Empresa.Cif
        insertar.Parameters.Add("@nombre", OleDbType.Char, 15).Value = txtNombre.Text
        insertar.Parameters.Add("@apellidos", OleDbType.Char, 50).Value = txtApellidos.Text
        insertar.Parameters.Add("@direccion", OleDbType.Char, 100).Value = txtDireccion.Text
        insertar.Parameters.Add("@localidad", OleDbType.Char, 25).Value = txtLocalidad.Text
        insertar.Parameters.Add("@provincia", OleDbType.Char, 25).Value = txtProvincia.Text
        insertar.Parameters.Add("@pais", OleDbType.Char, 25).Value = txtPais.Text
        insertar.Parameters.Add("@fijo", OleDbType.Integer, 12).Value = txtFijo.Text
        insertar.Parameters.Add("@movil", OleDbType.Integer, 12).Value = txtMovil.Text
        insertar.Parameters.Add("@email", OleDbType.Char, 50).Value = txtEmail.Text
        insertar.Parameters.Add("@cif", OleDbType.Char, 9).Value = txtCif.Text

        Dim j As Integer = insertar.ExecuteNonQuery()

        If txtEmpresa.Checked Then
            Dim sql As String = "UPDATE clientes SET empresa = ? WHERE id_cliente = ? AND CIF_EMPRESA = ?"
            Try
                Using comm = New OleDbCommand(sql, consConex)
                    comm.Parameters.AddWithValue("@p1", txtEmpresa.Checked)
                    comm.Parameters.AddWithValue("@p2", Convert.ToInt16(txtCliente.Text))
                    comm.Parameters.AddWithValue("@p3", Empresa.Cif)
                    comm.ExecuteNonQuery()
                End Using

            Catch ode As Exception
                MessageBox.Show(ode.StackTrace.ToString + ode.Message.ToString + "/ " + ode.Data.ToString)
            End Try
        ElseIf txtParticular.Checked Then
            Dim sql As String = "UPDATE clientes SET particular = ? WHERE id_cliente = ? AND CIF_EMPRESA = ?"
            Try
                Using comm = New OleDbCommand(sql, consConex)
                    comm.Parameters.AddWithValue("@p1", txtParticular.Checked)
                    comm.Parameters.AddWithValue("@p2", Convert.ToInt16(txtCliente.Text))
                    comm.Parameters.AddWithValue("@p3", Empresa.Cif)
                    comm.ExecuteNonQuery()
                End Using
            Catch ode As Exception
                MessageBox.Show(ode.StackTrace.ToString + ode.Message.ToString + "/ " + ode.Data.ToString)
            End Try
        End If
        If j > 0 Then
            MessageBox.Show("Cliente insertado")
            End If
        Catch ex As FormatException
            MessageBox.Show("Inserte todos los campos")
        End Try
    End Sub

    Private Sub btnInsertar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsertar.Click
        insertar()
        ocultar()
        limpiar()
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked

        Clientes.Show()
        Me.Close()

    End Sub

    Private Sub insertarCliente_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If borr = True Then
            lbAtras.Enabled = False
            lbAtras.Visible = False
            llSalir.Enabled = False
            llSalir.Visible = False
        End If
    End Sub

    Private Sub llSalir_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub
End Class