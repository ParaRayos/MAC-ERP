﻿Imports System.Data.OleDb

Public Class Clientes
    Dim borr As Boolean = False
    Public Property borrar() As Boolean
        Get
            Return borr
        End Get
        Set(ByVal value As Boolean)
            borr = value
        End Set
    End Property
    Private Sub btnAñadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAñadir.Click
        insertarCliente.borrar = borr
        insertarCliente.Show()
        Me.Close()
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        borrarCliente.borrar = borr
        borrarCliente.Show()
        Me.Close()
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        actualizarCliente.borrar = borr
        actualizarCliente.Show()
        Me.Close()
    End Sub

    Private Sub btnFacturar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFacturar.Click
        informeClientes.borrar = borr
        informeClientes.Show()
        Me.Close()
    End Sub

    Private Sub Clientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim tablaClientes As New DataTable
        Dim sql As String = "SELECT id_cliente, nombre, apellidos, pais, empresa, particular, telefono_movil, telefono_fijo, email FROM " & tabla3
        adapClientes = New OleDbDataAdapter(sql, consConex)
        adapClientes.Fill(tablaClientes)
        Me.dgvClientes.DataSource = tablaClientes
        Me.txtNombreEmpresa.Text = Empresa.Nombre
        If Usuario.propTipo.Equals("Supervisor") Then
            btnEliminar.Enabled = False
            btnEliminar.Visible = False
        ElseIf Usuario.propTipo.Equals("Empleado") Then
            btnEliminar.Enabled = False
            btnEliminar.Visible = False
            btnModificar.Enabled = False
            btnModificar.Visible = False
        End If
        If borr = True Then
            lbAtras.Enabled = False
            lbAtras.Visible = False
            llSalir.Enabled = False
            llSalir.Visible = False
        End If
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        MenuEmpresa.Show()
        Me.Close()
    End Sub

    Private Sub llSalir_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub
End Class