﻿Option Strict On
Imports System.Data.OleDb

Public Class actualizarCliente
    Dim borr As Boolean = False
    Public Property borrar() As Boolean
        Get
            Return borr
        End Get
        Set(ByVal value As Boolean)
            borr = value
        End Set
    End Property
    Public Sub mostrar()
        txtCif.Enabled = True
        txtNombre.Enabled = True
        txtApellidos.Enabled = True
        txtDireccion.Enabled = True
        txtLocalidad.Enabled = True
        txtProvincia.Enabled = True
        txtPais.Enabled = True
        txtParticular.Enabled = True
        txtEmpresa.Enabled = True
        txtFijo.Enabled = True
        txtMovil.Enabled = True
        txtEmail.Enabled = True
        btnActualizar.Enabled = True

        txtCliente.Enabled = False
        txtCif.Enabled = False
        btnBuscar.Visible = False
    End Sub

    Public Sub enlazarDatos()
        bindingClientes.DataSource = dataSetAlmacen
        bindingClientes.DataMember = tabla3
        Me.txtNombre.DataBindings.Add(New Binding("Text", bindingClientes, "NOMBRE", True))
        Me.txtApellidos.DataBindings.Add(New Binding("Text", bindingClientes, "APELLIDOS", True))
        Me.txtDireccion.DataBindings.Add(New Binding("Text", bindingClientes, "DIRECCION", True))
        Me.txtLocalidad.DataBindings.Add(New Binding("Text", bindingClientes, "LOCALIDAD", True))
        Me.txtProvincia.DataBindings.Add(New Binding("Text", bindingClientes, "PROVINCIA", True))
        Me.txtPais.DataBindings.Add(New Binding("Text", bindingClientes, "PAIS", True))
        Me.txtEmpresa.DataBindings.Add(New Binding("Checked", bindingClientes, "EMPRESA", True))
        Me.txtParticular.DataBindings.Add(New Binding("Checked", bindingClientes, "PARTICULAR", True))
        Me.txtFijo.DataBindings.Add(New Binding("Text", bindingClientes, "TELEFONO_FIJO", True))
        Me.txtMovil.DataBindings.Add(New Binding("Text", bindingClientes, "TELEFONO_MOVIL", True))
        Me.txtEmail.DataBindings.Add(New Binding("Text", bindingClientes, "EMAIL", True))
    End Sub

    Sub buscar()
        Dim cliente As Integer
        Dim cif As String

        If txtCliente.Text = "" Or txtCif.Text = "" Then
            MessageBox.Show("Introduzca todos los datos por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select * from clientes where id_cliente =@cliente and cif = @cif", consConex)

            comando.Parameters.Add("@cliente", OleDbType.Integer, 4).Value = Me.txtCliente.Text
            comando.Parameters.Add("@cif", OleDbType.Char, 9).Value = Me.txtCif.Text

            adapClientes = New OleDbDataAdapter(comando)
            adapClientes.Fill(dataSetAlmacen, tabla3)

            Try
                Dim fila As DataRow
                Dim fila2 As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)
                fila2 = dataSetAlmacen.Tables(0).Rows(0)

                cliente = CInt(fila("ID_CLIENTE"))
                cif = CStr(fila2("CIF"))

                Me.btnActualizar.Enabled = True
                Me.btnLimpiar.Enabled = True
                enlazarDatos()
                mostrar()
            Catch ex As IndexOutOfRangeException
                MessageBox.Show("No existe ningún cliente con esos datos.")
            End Try
        End If
    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        buscar()
    End Sub

    Public Sub limpiar()
        Dim frm As New actualizarCliente
        frm.Show()
        Me.Close()
    End Sub

    Private Sub btnLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Public Sub actualizar()
        Try
            Dim sql As String = "UPDATE clientes SET nombre =?, apellidos =?, direccion =?, localidad =?, provincia =?, pais =?, telefono_fijo =?, telefono_movil =?, email =? WHERE id_cliente = ? and cif = ?"
            Using actualizar = New OleDbCommand(sql, consConex)
                actualizar.Parameters.AddWithValue("@p1", txtNombre.Text)
                actualizar.Parameters.AddWithValue("@p2", txtApellidos.Text)
                actualizar.Parameters.AddWithValue("@p3", txtDireccion.Text)
                actualizar.Parameters.AddWithValue("@p4", txtLocalidad.Text)
                actualizar.Parameters.AddWithValue("@p5", txtProvincia.Text)
                actualizar.Parameters.AddWithValue("@p6", txtPais.Text)
                actualizar.Parameters.AddWithValue("@p7", Convert.ToInt64(txtFijo.Text))
                actualizar.Parameters.AddWithValue("@p8", Convert.ToInt64(txtMovil.Text))
                actualizar.Parameters.AddWithValue("@p9", txtEmail.Text)
                actualizar.Parameters.AddWithValue("@p10", Convert.ToInt16(txtCliente.Text))
                actualizar.Parameters.AddWithValue("@p11", txtCif.Text)
                If txtEmpresa.Checked Then
                    Dim sql2 As String = "UPDATE clientes SET empresa =? WHERE id_cliente = ? and cif = ?"
                    Using act = New OleDbCommand(sql2, consConex)
                        act.Parameters.AddWithValue("@p1", txtEmpresa.Checked)
                        act.Parameters.AddWithValue("@p2", Convert.ToInt16(txtCliente.Text))
                        act.Parameters.AddWithValue("@p3", txtCif.Text)
                        act.ExecuteNonQuery()
                    End Using

                Else
                    Dim sql2 As String = "UPDATE clientes SET empresa =? WHERE id_cliente = ? and cif = ?"
                    Using act = New OleDbCommand(sql2, consConex)
                        act.Parameters.AddWithValue("@p1", txtEmpresa.CheckState)
                        act.Parameters.AddWithValue("@p2", Convert.ToInt16(txtCliente.Text))
                        act.Parameters.AddWithValue("@p3", txtCif.Text)
                        act.ExecuteNonQuery()
                    End Using
                End If

                If txtParticular.Checked Then
                    Dim sql2 As String = "UPDATE clientes SET particular =? WHERE id_cliente = ? and cif = ?"
                    Using act = New OleDbCommand(sql2, consConex)
                        act.Parameters.AddWithValue("@p1", txtParticular.Checked)
                        act.Parameters.AddWithValue("@p2", Convert.ToInt16(txtCliente.Text))
                        act.Parameters.AddWithValue("@p3", txtCif.Text)
                        act.ExecuteNonQuery()
                    End Using

                Else
                    Dim sql2 As String = "UPDATE clientes SET particular =? WHERE id_cliente = ? and cif = ?"
                    Using act = New OleDbCommand(sql2, consConex)
                        act.Parameters.AddWithValue("@p1", txtParticular.CheckState)
                        act.Parameters.AddWithValue("@p2", Convert.ToInt16(txtCliente.Text))
                        act.Parameters.AddWithValue("@p3", txtCif.Text)
                        act.ExecuteNonQuery()
                    End Using
                End If


                actualizar.ExecuteNonQuery()
            End Using
        Catch ex As FormatException
            MessageBox.Show("Inserte todos los campos")
        End Try
    End Sub

    Private Sub btnActualizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnActualizar.Click
        actualizar()
        limpiar()
    End Sub

    Private Sub actualizarCliente_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If borr = True Then
            lbAtras.Enabled = False
            lbAtras.Visible = False
            llSalir.Enabled = False
            llSalir.Visible = False
        End If
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        Clientes.Show()
        Me.Close()
    End Sub

    Private Sub llSalir_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub
End Class