﻿Option Strict On
Imports System.IO
Imports System.Data.OleDb
Public Class AñadirProducto
    Dim openFileDialog1 As New OpenFileDialog()
    Dim contadorArticulos As Integer
    Dim puedeGrabar As Boolean = False
    Dim clipText As String
    Dim borr As Boolean = False
    Public Property borrar() As Boolean
        Get
            Return borr
        End Get
        Set(ByVal value As Boolean)
            borr = value
        End Set
    End Property
    Private Sub btnAñadirProducto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAñadirProducto.Click
        recogerDatos()
        If puedeGrabar Then
            Dim folder As String = Path.Combine(Application.StartupPath, "Imagenes\Productos")
            guaIma(pbImagen, folder, openFileDialog1.SafeFileName)
            insPro(BD.consConex)
            contadorArticulos += 1
            txtCodigo.Text = CStr(contadorArticulos)
            txtNombre.Text = ""
            txtTipo.Text = ""
            txtDescripcion.Text = ""
            txtPrecio.Text = ""
            txtDivisa.Text = ""
            txtExistencia.Text = ""
            pbImagen.Image = Nothing
            openFileDialog1 = New OpenFileDialog
        End If
    End Sub

    Private Sub recogerDatos()
        comprobarCampos()
        If puedeGrabar Then
            Producto.CodArticulo = txtCodigo.Text
            Producto.NombreProducto = txtNombre.Text
            Producto.TipoProducto = txtTipo.Text
            Producto.Descripcion = txtDescripcion.Text
            Producto.Precio = CType(txtPrecio.Text, Double)
            Producto.Divisa = txtDivisa.Text
            Producto.Existencias = CInt(txtExistencia.Text)
        End If
    End Sub

    Private Sub comprobarCampos()
        If txtCodigo.Text = "" Or txtDescripcion.Text = "" Or txtDivisa.Text = "" Or txtExistencia.Text = "" Or txtNombre.Text = "" Or txtPrecio.Text = "" Or txtTipo.Text = "" Then
            MessageBox.Show("Faltan campos por completar.", "INFORMACION", MessageBoxButtons.OK)
        Else
            puedeGrabar = True
        End If
    End Sub

    Private Sub pbImagen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbImagen.Click
        Dim folder As String = Path.Combine(Application.StartupPath, "Imagenes\Productos")
        If (Not Directory.Exists(folder)) Then
            Directory.CreateDirectory(folder)
        End If
        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "Archivos jpeg (*.jpeg)|*.jpeg|Todos los archivos (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            If openFileDialog1.FileName <> "" Then
                pbImagen.Image = Image.FromFile(openFileDialog1.FileName)
            End If
        End If
    End Sub

    Sub guaIma(ByVal pb As PictureBox, ByVal ru As String, ByVal arc As String)
        Dim fileName As String = ru + "\" + arc
        If System.IO.File.Exists(fileName) Then
            Dim arS() As String = Split(arc, CChar("."))
            arS(0) = arS(0) + "1"
            arc = arS(0) + "." + arS(1)
            guaIma(pb, ru, arc)
            Exit Sub
        Else
            Try
                pbImagen.Image.Save(fileName, System.Drawing.Imaging.ImageFormat.Jpeg)
            Catch ex As NullReferenceException
                arc = "MAC ERP.jpg"
            End Try
        End If
        Producto.RutaImagen = "\Imagenes\Productos\" + arc
    End Sub

    Private Sub AñadirProducto_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        comprobarNumeroRegistros(BD.consConex)
        contadorArticulos += 1
        txtCodigo.Text = CStr(contadorArticulos)
        If borr = True Then
            lbAtras.Enabled = False
            lbAtras.Visible = False
            llSalir.Enabled = False
            llSalir.Visible = False
        End If
    End Sub

    Public Sub comprobarNumeroRegistros(ByVal conexion As OleDbConnection)
        Dim tablaProductos As New DataTable
        Dim adapProductos As New OleDbDataAdapter
        Dim sql As String = "Select * from Productos where cif_empresa = '" + Empresa.Cif + "'"
        Dim comando As New OleDbCommand

        comando.Connection = conexion
        comando.CommandText = sql
        adapProductos.SelectCommand = comando
        adapProductos.Fill(tablaProductos)
        comando.ExecuteNonQuery()
        contadorArticulos = tablaProductos.Rows.Count()
    End Sub

    Private Sub txtPrecio_GotFocus(sender As Object, e As System.EventArgs) Handles txtPrecio.GotFocus, txtExistencia.GotFocus
        If Clipboard.ContainsText Then
            clipText = Clipboard.GetText
            Clipboard.Clear()
        End If
    End Sub

    Private Sub txtPrecio_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtPrecio.KeyPress
        If (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or e.KeyChar = Chr(46)) Then

        Else
            e.Handled = True
        End If
    End Sub

    Private Sub llSalir_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub

    Private Sub lbAtras_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        PantallaProductos.Show()
        Me.Close()
    End Sub

    Private Sub txtExistencia_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtExistencia.KeyPress
        If (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar)) Then

        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtExistencia_LostFocus(sender As Object, e As System.EventArgs) Handles txtExistencia.LostFocus, txtPrecio.LostFocus
        If Clipboard.ContainsText = False And Clipboard.ContainsImage = False And Clipboard.ContainsAudio = False And Clipboard.ContainsFileDropList = False Then
            Clipboard.SetText(clipText)
        End If
    End Sub

    Private Sub btnBorrarCajas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrarCajas.Click
        txtNombre.Text = ""
        txtTipo.Text = ""
        txtDescripcion.Text = ""
        txtPrecio.Text = ""
        txtDivisa.Text = ""
        txtExistencia.Text = ""
    End Sub
End Class