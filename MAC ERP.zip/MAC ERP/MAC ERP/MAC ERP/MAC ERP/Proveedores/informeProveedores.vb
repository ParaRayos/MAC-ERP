﻿Imports System.Data.OleDb

Public Class informeProveedores
    Dim borr As Boolean = False
    Public Property borrar() As Boolean
        Get
            Return borr
        End Get
        Set(ByVal value As Boolean)
            borr = value
        End Set
    End Property
    Private Sub informeProveedores_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If borr = False Then
            Proveedores.Show()
        End If
    End Sub

    Private Sub informeProveedores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dataSetAlmacen = New DataSet
        dataSetAlmacen.Clear()
        Dim sql As String = "SELECT * FROM proveedores WHERE cif_empresa = '" & Empresa.Cif & "'"

        adapProveedores = New OleDbDataAdapter(sql, consConex)

        adapProveedores.Fill(dataSetAlmacen, tabla4)

        Dim rpt As New informeProveedor
        rpt.SetDataSource(dataSetAlmacen)
        Me.CrystalReportViewer1.ReportSource = rpt
    End Sub
End Class