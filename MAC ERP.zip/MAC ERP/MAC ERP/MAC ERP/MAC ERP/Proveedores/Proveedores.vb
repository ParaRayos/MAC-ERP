﻿Imports System.Data.OleDb

Public Class Proveedores
    Dim borr As Boolean = False
    Public Property borrar() As Boolean
        Get
            Return borr
        End Get
        Set(ByVal value As Boolean)
            borr = value
        End Set
    End Property
    Private Sub btnAñadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAñadir.Click
        insertarProveedor.borrar = borr
        insertarProveedor.Show()
        Me.Close()
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        borrarProveedor.borrar = borr
        borrarProveedor.Show()
        Me.Close()
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        actualizarProveedor.borrar = borr
        actualizarProveedor.Show()
        Me.Close()
    End Sub

    Private Sub btnFacturar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFacturar.Click
        informeProveedores.borrar = borr
        informeProveedores.Show()
        Me.Close()
    End Sub

    Private Sub Proveedores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim tablaproveedores As New DataTable
        Dim sql As String = "SELECT id_proveedor, nombre, apellidos, pais, empresa, particular, telefono_movil, telefono_fijo, email  FROM " & tabla4
        adapProveedores = New OleDbDataAdapter(sql, consConex)
        adapProveedores.Fill(tablaproveedores)
        Me.dgvProveedores.DataSource = tablaproveedores
        Me.txtNombreEmpresa.Text = Empresa.Nombre
        If Usuario.propTipo.Equals("Supervisor") Then
            btnEliminar.Enabled = False
            btnEliminar.Visible = False
        ElseIf Usuario.propTipo.Equals("Empleado") Then
            btnEliminar.Enabled = False
            btnEliminar.Visible = False
            btnModificar.Enabled = False
            btnModificar.Visible = False
        End If
        If borr = True Then
            lbAtras.Enabled = False
            lbAtras.Visible = False
            llSalir.Enabled = False
            llSalir.Visible = False
        End If
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        MenuEmpresa.Show()
        Me.Close()
    End Sub

    Private Sub llSalir_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub
End Class