﻿Imports System.IO
Imports System.Data.OleDb

Public Class MenuEmpresa
    Dim act As Boolean = True
    Private Sub btnAlmacen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAlmacen.Click
        PantallaProductos.Show()
        Me.Close()
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        desbloquearCampos()
        btnGuardar.Visible = True
    End Sub

    Public Sub desbloquearCampos()
        txtCif.ReadOnly = False
        txtNombre.ReadOnly = False
        txtLocalidad.ReadOnly = False
        txtProvincia.ReadOnly = False
        txtPais.ReadOnly = False
        txtCodPostal.ReadOnly = False
        txtSector.ReadOnly = False

        txtCif.BackColor = Color.White
        txtNombre.BackColor = Color.White
        txtLocalidad.BackColor = Color.White
        txtProvincia.BackColor = Color.White
        txtPais.BackColor = Color.White
        txtCodPostal.BackColor = Color.White
        txtSector.BackColor = Color.White
    End Sub

    Public Sub bloquearCampos()
        txtCif.ReadOnly = True
        txtNombre.ReadOnly = True
        txtLocalidad.ReadOnly = True
        txtProvincia.ReadOnly = True
        txtPais.ReadOnly = True
        txtCodPostal.ReadOnly = True
        txtSector.ReadOnly = True

        txtCif.BackColor = Color.Honeydew
        txtNombre.BackColor = Color.Honeydew
        txtLocalidad.BackColor = Color.Honeydew
        txtProvincia.BackColor = Color.Honeydew
        txtPais.BackColor = Color.Honeydew
        txtCodPostal.BackColor = Color.Honeydew
        txtSector.BackColor = Color.Honeydew
    End Sub

    Private Sub btnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGuardar.Click
        bloquearCampos()
        btnGuardar.Visible = False
        Dim sql As String = "UPDATE Empresa SET cif= ?, nombre =?, pais =?, provincia =?, sector =?, localidad =?, cod_postal = ? WHERE cif = ?"
        Using actualizar = New OleDbCommand(sql, consConex)
            actualizar.Parameters.AddWithValue("@p1", txtCif.Text)
            actualizar.Parameters.AddWithValue("@p2", txtNombre.Text)
            actualizar.Parameters.AddWithValue("@p3", txtPais.Text)
            actualizar.Parameters.AddWithValue("@p4", txtProvincia.Text)
            actualizar.Parameters.AddWithValue("@p5", txtSector.Text)
            actualizar.Parameters.AddWithValue("@p6", txtLocalidad.Text)
            actualizar.Parameters.AddWithValue("@p7", txtCodPostal.Text)
            actualizar.Parameters.AddWithValue("@p8", Empresa.Cif)
            actualizar.ExecuteNonQuery()
            MessageBox.Show("Modificación terminada correctamente", "Información:", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Using
        Empresa.Cif = txtCif.Text
        Empresa.Nombre = txtNombre.Text
        Empresa.Pais = txtPais.Text
        Empresa.Provincia = txtProvincia.Text
        Empresa.Sector = txtSector.Text
        Empresa.Localidad = txtLocalidad.Text
    End Sub

    Private Sub MenuEmpresa_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        txtCif.Text = Empresa.Cif
        txtNombre.Text = Empresa.Nombre
        txtLocalidad.Text = Empresa.Localidad
        txtProvincia.Text = Empresa.Provincia
        txtPais.Text = Empresa.Pais
        txtSector.Text = Empresa.Sector
        txtCodPostal.Text = Empresa.CodPostal
        txtNombreEmpresa.Text = Empresa.Nombre.ToUpper
        Dim ruta As String = Application.StartupPath + Empresa.RutaImagen
        If File.Exists(ruta) Then
            pbLogo.Image = Image.FromFile(ruta)
        Else
            pbLogo.Image = Image.FromFile(Path.Combine(Application.StartupPath, "Imagenes\Empresas\MAC ERP.jpg"))
            Dim com As New OleDbCommand("Update empresa set [ruta_imagen]=@ruta where cif=@cif", consConex)
            com.Parameters.Add("@ruta", OleDbType.Char, 100).Value = "\Imagenes\Empresas\MAC ERP.jpg"
            com.Parameters.Add("@cif", OleDbType.Char, 9).Value = Empresa.Cif
            com.ExecuteNonQuery()
            Empresa.RutaImagen = "\Imagenes\Empresas\MAC ERP.jpg"
        End If
        If Usuario.propTipo.Equals("Supervisor") Then
            btnModificar.Enabled = False
            btnModificar.Visible = False
        ElseIf Usuario.propTipo.Equals("Empleado") Then
            btnModificar.Enabled = False
            btnModificar.Visible = False
        End If
    End Sub

    Private Sub llCerr_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llCerr.LinkClicked
        frmLogin.Show()
        Me.Close()
    End Sub

    Private Sub lbOpc_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)
        CambiarContraseña.llama = "SDI"
        CambiarContraseña.Show()
        Me.Close()
    End Sub

    Private Sub btnClientes_Click(sender As System.Object, e As System.EventArgs) Handles btnClientes.Click
        Clientes.Show()
        Me.Close()
    End Sub

    Private Sub btnProveedores_Click(sender As System.Object, e As System.EventArgs) Handles btnProveedores.Click
        Proveedores.Show()
        Me.Close()
    End Sub

    Private Sub btnVentas_Click(sender As System.Object, e As System.EventArgs) Handles btnVentas.Click
        Ventas.Show()
        Me.Close()
    End Sub

    Private Sub btnCompras_Click(sender As System.Object, e As System.EventArgs) Handles btnCompras.Click
        Compras.Show()
        Me.Close()
    End Sub

    Private Sub CambiarContraseñaToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CambiarContraseñaToolStripMenuItem.Click
        CambiarContraseña.Show()
        Me.Close()

    End Sub

    Private Sub BorrarEmpresaToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs)
        borr(Me)
    End Sub

    Private Sub lbOpciones_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbOpciones.LinkClicked
        cMS.Show(Me.lbOpciones, 0, 14)
    End Sub

    Private Sub lbOpciones_MouseClick(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles lbOpciones.MouseClick
        cMS.Show(Me.lbOpciones, 0, 14)
    End Sub

    Private Sub SalirDeLaAplicaciónToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalirDeLaAplicaciónToolStripMenuItem.Click
        desconecta()
        Me.Close()
    End Sub

    Private Sub InsertarUsuarioToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InsertarUsuarioToolStripMenuItem.Click
        CrearUsuario.lla = "EMPRESA1"
        CrearUsuario.Show()
        Me.Close()
    End Sub
End Class