﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenEmMDI
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MenEmMDI))
        Me.msMDI = New System.Windows.Forms.MenuStrip()
        Me.ArchivoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CerrarSesiónToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CerrarVentanaActualToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CerrarTodasLasVentanasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirDeLaAplicaciónToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VentasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListadoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertarVentasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrarVentasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActualizarVentasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComprasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListadoToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertarCompraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrarCompraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActualizarCompraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClientesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListadoToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertarClienteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrarClienteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModificarClienteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListadoToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertarProductoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActualizarProductoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProveedoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListadoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertarProveedorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrarProveedorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActualizarProveedorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpcionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CambiarContraseñaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModificarDatosDeLaEmpresaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InsertarUsuarioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrarEmpresaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrganizarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HorizontalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerticalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnCascadaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.msMDI.SuspendLayout()
        Me.SuspendLayout()
        '
        'msMDI
        '
        Me.msMDI.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ArchivoToolStripMenuItem, Me.VentasToolStripMenuItem, Me.ComprasToolStripMenuItem, Me.ClientesToolStripMenuItem, Me.ProductosToolStripMenuItem, Me.ProveedoresToolStripMenuItem, Me.OpcionesToolStripMenuItem, Me.OrganizarToolStripMenuItem})
        Me.msMDI.Location = New System.Drawing.Point(0, 0)
        Me.msMDI.Name = "msMDI"
        Me.msMDI.Size = New System.Drawing.Size(1210, 24)
        Me.msMDI.TabIndex = 1
        Me.msMDI.Text = "MenuStrip1"
        '
        'ArchivoToolStripMenuItem
        '
        Me.ArchivoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CerrarSesiónToolStripMenuItem, Me.CerrarVentanaActualToolStripMenuItem, Me.CerrarTodasLasVentanasToolStripMenuItem, Me.SalirDeLaAplicaciónToolStripMenuItem})
        Me.ArchivoToolStripMenuItem.Name = "ArchivoToolStripMenuItem"
        Me.ArchivoToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.ArchivoToolStripMenuItem.Text = "Archivo"
        '
        'CerrarSesiónToolStripMenuItem
        '
        Me.CerrarSesiónToolStripMenuItem.Name = "CerrarSesiónToolStripMenuItem"
        Me.CerrarSesiónToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.CerrarSesiónToolStripMenuItem.Text = "Cerrar sesión"
        '
        'CerrarVentanaActualToolStripMenuItem
        '
        Me.CerrarVentanaActualToolStripMenuItem.Name = "CerrarVentanaActualToolStripMenuItem"
        Me.CerrarVentanaActualToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.CerrarVentanaActualToolStripMenuItem.Text = "Cerrar ventana actual"
        '
        'CerrarTodasLasVentanasToolStripMenuItem
        '
        Me.CerrarTodasLasVentanasToolStripMenuItem.Name = "CerrarTodasLasVentanasToolStripMenuItem"
        Me.CerrarTodasLasVentanasToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.CerrarTodasLasVentanasToolStripMenuItem.Text = "Cerrar todas las ventanas"
        '
        'SalirDeLaAplicaciónToolStripMenuItem
        '
        Me.SalirDeLaAplicaciónToolStripMenuItem.Name = "SalirDeLaAplicaciónToolStripMenuItem"
        Me.SalirDeLaAplicaciónToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.SalirDeLaAplicaciónToolStripMenuItem.Text = "Salir de la aplicación"
        '
        'VentasToolStripMenuItem
        '
        Me.VentasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListadoToolStripMenuItem, Me.InsertarVentasToolStripMenuItem, Me.BorrarVentasToolStripMenuItem, Me.ActualizarVentasToolStripMenuItem})
        Me.VentasToolStripMenuItem.Name = "VentasToolStripMenuItem"
        Me.VentasToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.VentasToolStripMenuItem.Text = "Ventas"
        '
        'ListadoToolStripMenuItem
        '
        Me.ListadoToolStripMenuItem.Name = "ListadoToolStripMenuItem"
        Me.ListadoToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.ListadoToolStripMenuItem.Text = "Listado"
        '
        'InsertarVentasToolStripMenuItem
        '
        Me.InsertarVentasToolStripMenuItem.Name = "InsertarVentasToolStripMenuItem"
        Me.InsertarVentasToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.InsertarVentasToolStripMenuItem.Text = "Insertar ventas"
        '
        'BorrarVentasToolStripMenuItem
        '
        Me.BorrarVentasToolStripMenuItem.Name = "BorrarVentasToolStripMenuItem"
        Me.BorrarVentasToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.BorrarVentasToolStripMenuItem.Text = "Borrar ventas"
        '
        'ActualizarVentasToolStripMenuItem
        '
        Me.ActualizarVentasToolStripMenuItem.Name = "ActualizarVentasToolStripMenuItem"
        Me.ActualizarVentasToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.ActualizarVentasToolStripMenuItem.Text = "Actualizar Ventas"
        '
        'ComprasToolStripMenuItem
        '
        Me.ComprasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListadoToolStripMenuItem4, Me.InsertarCompraToolStripMenuItem, Me.BorrarCompraToolStripMenuItem, Me.ActualizarCompraToolStripMenuItem})
        Me.ComprasToolStripMenuItem.Name = "ComprasToolStripMenuItem"
        Me.ComprasToolStripMenuItem.Size = New System.Drawing.Size(67, 20)
        Me.ComprasToolStripMenuItem.Text = "Compras"
        '
        'ListadoToolStripMenuItem4
        '
        Me.ListadoToolStripMenuItem4.Name = "ListadoToolStripMenuItem4"
        Me.ListadoToolStripMenuItem4.Size = New System.Drawing.Size(170, 22)
        Me.ListadoToolStripMenuItem4.Text = "Listado"
        '
        'InsertarCompraToolStripMenuItem
        '
        Me.InsertarCompraToolStripMenuItem.Name = "InsertarCompraToolStripMenuItem"
        Me.InsertarCompraToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.InsertarCompraToolStripMenuItem.Text = "Insertar compra"
        '
        'BorrarCompraToolStripMenuItem
        '
        Me.BorrarCompraToolStripMenuItem.Name = "BorrarCompraToolStripMenuItem"
        Me.BorrarCompraToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.BorrarCompraToolStripMenuItem.Text = "Borrar compra"
        '
        'ActualizarCompraToolStripMenuItem
        '
        Me.ActualizarCompraToolStripMenuItem.Name = "ActualizarCompraToolStripMenuItem"
        Me.ActualizarCompraToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.ActualizarCompraToolStripMenuItem.Text = "Actualizar compra"
        '
        'ClientesToolStripMenuItem
        '
        Me.ClientesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListadoToolStripMenuItem3, Me.InsertarClienteToolStripMenuItem, Me.BorrarClienteToolStripMenuItem, Me.ModificarClienteToolStripMenuItem})
        Me.ClientesToolStripMenuItem.Name = "ClientesToolStripMenuItem"
        Me.ClientesToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.ClientesToolStripMenuItem.Text = "Clientes"
        '
        'ListadoToolStripMenuItem3
        '
        Me.ListadoToolStripMenuItem3.Name = "ListadoToolStripMenuItem3"
        Me.ListadoToolStripMenuItem3.Size = New System.Drawing.Size(164, 22)
        Me.ListadoToolStripMenuItem3.Text = "Listado"
        '
        'InsertarClienteToolStripMenuItem
        '
        Me.InsertarClienteToolStripMenuItem.Name = "InsertarClienteToolStripMenuItem"
        Me.InsertarClienteToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.InsertarClienteToolStripMenuItem.Text = "Insertar cliente"
        '
        'BorrarClienteToolStripMenuItem
        '
        Me.BorrarClienteToolStripMenuItem.Name = "BorrarClienteToolStripMenuItem"
        Me.BorrarClienteToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.BorrarClienteToolStripMenuItem.Text = "Borrar cliente"
        '
        'ModificarClienteToolStripMenuItem
        '
        Me.ModificarClienteToolStripMenuItem.Name = "ModificarClienteToolStripMenuItem"
        Me.ModificarClienteToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.ModificarClienteToolStripMenuItem.Text = "Actualizar cliente"
        '
        'ProductosToolStripMenuItem
        '
        Me.ProductosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListadoToolStripMenuItem2, Me.InsertarProductoToolStripMenuItem, Me.ActualizarProductoToolStripMenuItem})
        Me.ProductosToolStripMenuItem.Name = "ProductosToolStripMenuItem"
        Me.ProductosToolStripMenuItem.Size = New System.Drawing.Size(73, 20)
        Me.ProductosToolStripMenuItem.Text = "Productos"
        '
        'ListadoToolStripMenuItem2
        '
        Me.ListadoToolStripMenuItem2.Name = "ListadoToolStripMenuItem2"
        Me.ListadoToolStripMenuItem2.Size = New System.Drawing.Size(178, 22)
        Me.ListadoToolStripMenuItem2.Text = "Listado"
        '
        'InsertarProductoToolStripMenuItem
        '
        Me.InsertarProductoToolStripMenuItem.Name = "InsertarProductoToolStripMenuItem"
        Me.InsertarProductoToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.InsertarProductoToolStripMenuItem.Text = "Insertar producto"
        '
        'ActualizarProductoToolStripMenuItem
        '
        Me.ActualizarProductoToolStripMenuItem.Name = "ActualizarProductoToolStripMenuItem"
        Me.ActualizarProductoToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.ActualizarProductoToolStripMenuItem.Text = "Actualizar producto"
        '
        'ProveedoresToolStripMenuItem
        '
        Me.ProveedoresToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListadoToolStripMenuItem1, Me.InsertarProveedorToolStripMenuItem, Me.BorrarProveedorToolStripMenuItem, Me.ActualizarProveedorToolStripMenuItem})
        Me.ProveedoresToolStripMenuItem.Name = "ProveedoresToolStripMenuItem"
        Me.ProveedoresToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.ProveedoresToolStripMenuItem.Text = "Proveedores"
        '
        'ListadoToolStripMenuItem1
        '
        Me.ListadoToolStripMenuItem1.Name = "ListadoToolStripMenuItem1"
        Me.ListadoToolStripMenuItem1.Size = New System.Drawing.Size(183, 22)
        Me.ListadoToolStripMenuItem1.Text = "Listado"
        '
        'InsertarProveedorToolStripMenuItem
        '
        Me.InsertarProveedorToolStripMenuItem.Name = "InsertarProveedorToolStripMenuItem"
        Me.InsertarProveedorToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
        Me.InsertarProveedorToolStripMenuItem.Text = "Insertar proveedor"
        '
        'BorrarProveedorToolStripMenuItem
        '
        Me.BorrarProveedorToolStripMenuItem.Name = "BorrarProveedorToolStripMenuItem"
        Me.BorrarProveedorToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
        Me.BorrarProveedorToolStripMenuItem.Text = "Borrar proveedor"
        '
        'ActualizarProveedorToolStripMenuItem
        '
        Me.ActualizarProveedorToolStripMenuItem.Name = "ActualizarProveedorToolStripMenuItem"
        Me.ActualizarProveedorToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
        Me.ActualizarProveedorToolStripMenuItem.Text = "Actualizar proveedor"
        '
        'OpcionesToolStripMenuItem
        '
        Me.OpcionesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CambiarContraseñaToolStripMenuItem, Me.ModificarDatosDeLaEmpresaToolStripMenuItem, Me.InsertarUsuarioToolStripMenuItem, Me.BorrarEmpresaToolStripMenuItem})
        Me.OpcionesToolStripMenuItem.Name = "OpcionesToolStripMenuItem"
        Me.OpcionesToolStripMenuItem.Size = New System.Drawing.Size(69, 20)
        Me.OpcionesToolStripMenuItem.Text = "Opciones"
        '
        'CambiarContraseñaToolStripMenuItem
        '
        Me.CambiarContraseñaToolStripMenuItem.Name = "CambiarContraseñaToolStripMenuItem"
        Me.CambiarContraseñaToolStripMenuItem.Size = New System.Drawing.Size(237, 22)
        Me.CambiarContraseñaToolStripMenuItem.Text = "Cambiar contraseña"
        '
        'ModificarDatosDeLaEmpresaToolStripMenuItem
        '
        Me.ModificarDatosDeLaEmpresaToolStripMenuItem.Name = "ModificarDatosDeLaEmpresaToolStripMenuItem"
        Me.ModificarDatosDeLaEmpresaToolStripMenuItem.Size = New System.Drawing.Size(237, 22)
        Me.ModificarDatosDeLaEmpresaToolStripMenuItem.Text = "Modificar datos de la empresa"
        '
        'InsertarUsuarioToolStripMenuItem
        '
        Me.InsertarUsuarioToolStripMenuItem.Name = "InsertarUsuarioToolStripMenuItem"
        Me.InsertarUsuarioToolStripMenuItem.Size = New System.Drawing.Size(237, 22)
        Me.InsertarUsuarioToolStripMenuItem.Text = "Insertar usuario"
        '
        'BorrarEmpresaToolStripMenuItem
        '
        Me.BorrarEmpresaToolStripMenuItem.Name = "BorrarEmpresaToolStripMenuItem"
        Me.BorrarEmpresaToolStripMenuItem.Size = New System.Drawing.Size(237, 22)
        Me.BorrarEmpresaToolStripMenuItem.Text = "Dar de baja a la empresa actual"
        '
        'OrganizarToolStripMenuItem
        '
        Me.OrganizarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HorizontalToolStripMenuItem, Me.VerticalToolStripMenuItem, Me.EnCascadaToolStripMenuItem})
        Me.OrganizarToolStripMenuItem.Name = "OrganizarToolStripMenuItem"
        Me.OrganizarToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.OrganizarToolStripMenuItem.Text = "Organizar"
        '
        'HorizontalToolStripMenuItem
        '
        Me.HorizontalToolStripMenuItem.Name = "HorizontalToolStripMenuItem"
        Me.HorizontalToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.HorizontalToolStripMenuItem.Text = "Horizontal"
        '
        'VerticalToolStripMenuItem
        '
        Me.VerticalToolStripMenuItem.Name = "VerticalToolStripMenuItem"
        Me.VerticalToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.VerticalToolStripMenuItem.Text = "Vertical"
        '
        'EnCascadaToolStripMenuItem
        '
        Me.EnCascadaToolStripMenuItem.Name = "EnCascadaToolStripMenuItem"
        Me.EnCascadaToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.EnCascadaToolStripMenuItem.Text = "En cascada"
        '
        'MenEmMDI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Honeydew
        Me.ClientSize = New System.Drawing.Size(1210, 704)
        Me.ControlBox = False
        Me.Controls.Add(Me.msMDI)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MenEmMDI"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MAC ERP"
        Me.msMDI.ResumeLayout(False)
        Me.msMDI.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents msMDI As System.Windows.Forms.MenuStrip
    Friend WithEvents ArchivoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VentasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComprasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClientesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpcionesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CerrarSesiónToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CambiarContraseñaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModificarDatosDeLaEmpresaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertarUsuarioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BorrarEmpresaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalirDeLaAplicaciónToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CerrarVentanaActualToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CerrarTodasLasVentanasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrganizarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HorizontalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerticalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnCascadaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListadoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertarVentasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BorrarVentasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActualizarVentasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListadoToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertarProductoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActualizarProductoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProveedoresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListadoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertarProveedorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActualizarProveedorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BorrarProveedorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListadoToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertarClienteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BorrarClienteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModificarClienteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListadoToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertarCompraToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BorrarCompraToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActualizarCompraToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
