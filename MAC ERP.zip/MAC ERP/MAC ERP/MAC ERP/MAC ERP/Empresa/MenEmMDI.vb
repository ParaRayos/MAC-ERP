﻿Public Class MenEmMDI
    Dim pr As New PantallaProductos
    Dim co As New Compras
    Dim cc As New CambiarContraseña
    Dim ve As New Ventas
    Dim cl As New Clientes
    Dim em As New MenuEmpresa
    Dim cU As New CrearUsuario
    Dim iV As New insertarVenta
    Dim bV As New borrarVentas
    Dim aV As New actualizarVenta
    Dim ac As New actualizarCompra
    Dim bc As New borrarCompras
    Dim ic As New insertarCompra
    Dim acl As New actualizarCliente
    Dim bcl As New borrarCliente
    Dim icl As New insertarCliente
    Dim ap As New AñadirProducto
    Dim mp As New ModificarProducto
    Dim apr As New actualizarProveedor
    Dim bpr As New borrarProveedor
    Dim ipr As New insertarProveedor
    Dim pro As New Proveedores
    Private Sub CambiarContraseñaToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CambiarContraseñaToolStripMenuItem.Click
        If cc.Visible = False Or cc.IsDisposed Then
            cc = New CambiarContraseña
            cc.llama = "MDI"
            cc.MdiParent = Me
            cc.Show()
        End If
    End Sub
    Private Sub BorrarEmpresaToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles BorrarEmpresaToolStripMenuItem.Click
        If em.Visible = True Or em.IsDisposed = False Then
            em.Close()
            em.Dispose()
        End If
        borr(Me)
    End Sub

    Private Sub ModificarDatosDeLaEmpresaToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ModificarDatosDeLaEmpresaToolStripMenuItem.Click
        If em.Visible = False Or em.IsDisposed Then
            em = New MenuEmpresa
            em.btnAlmacen.Enabled = False
            em.btnAlmacen.Visible = False
            em.btnClientes.Enabled = False
            em.btnClientes.Visible = False
            em.btnCompras.Enabled = False
            em.btnCompras.Visible = False
            em.btnProveedores.Enabled = False
            em.btnProveedores.Visible = False
            em.btnVentas.Enabled = False
            em.btnVentas.Visible = False
            em.llCerr.Enabled = False
            em.llCerr.Visible = False
            em.lbOpciones.Enabled = False
            em.lbOpciones.Visible = False
            em.MdiParent = Me
            em.Show()
        End If
    End Sub

    Private Sub InsertarUsuarioToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InsertarUsuarioToolStripMenuItem.Click
        If cU.Visible = False Or cU.IsDisposed Then
            cU = New CrearUsuario
            cU.lla = "EMPRESA"
            cU.MdiParent = Me
            cU.Show()
        End If
    End Sub

    Private Sub SalirDeLaAplicaciónToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalirDeLaAplicaciónToolStripMenuItem.Click
        desconecta()
        Me.Close()
    End Sub

    Private Sub CerrarVentanaActualToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CerrarVentanaActualToolStripMenuItem.Click
        Try
            Me.ActiveMdiChild.Close()
        Catch nr As NullReferenceException
        End Try
    End Sub

    Private Sub CerrarTodasLasVentanasToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CerrarTodasLasVentanasToolStripMenuItem.Click
        For Each frm As Form In Me.MdiChildren
            frm.Close()
        Next
    End Sub

    Private Sub HorizontalToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles HorizontalToolStripMenuItem.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub VerticalToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles VerticalToolStripMenuItem.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub EnCascadaToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles EnCascadaToolStripMenuItem.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub CerrarSesiónToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CerrarSesiónToolStripMenuItem.Click
        For Each frm As Form In Me.MdiChildren
            frm.Close()
        Next
        frmLogin.Show()
        Me.Close()
    End Sub

    Private Sub ListadoToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ListadoToolStripMenuItem.Click
        If ve.Visible = False Or ve.IsDisposed Then
            ve = New Ventas
            ve.borrar = True
            ve.MdiParent = Me
            ve.Show()
        End If
    End Sub

    Private Sub InsertarVentasToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InsertarVentasToolStripMenuItem.Click
        If iV.Visible = False Or iV.IsDisposed Then
            iV = New insertarVenta
            iV.borrar = True
            iV.MdiParent = Me
            iV.Show()
        End If
    End Sub

    Private Sub BorrarVentasToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles BorrarVentasToolStripMenuItem.Click
        If bV.Visible = False Or bV.IsDisposed Then
            bV = New borrarVentas
            bV.borrar = True
            bV.MdiParent = Me
            bV.Show()
        End If
    End Sub

    Private Sub ActualizarVentasToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ActualizarVentasToolStripMenuItem.Click
        If aV.Visible = False Or aV.IsDisposed Then
            aV = New actualizarVenta
            aV.borrar = True
            aV.MdiParent = Me
            aV.Show()
        End If
    End Sub

    Private Sub ModificarClienteToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ModificarClienteToolStripMenuItem.Click
        If acl.Visible = False Or acl.IsDisposed Then
            acl = New actualizarCliente
            acl.borrar = True
            acl.MdiParent = Me
            acl.Show()
        End If
    End Sub

    Private Sub MenEmMDI_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Usuario.propTipo.Equals("Supervisor") Then
            VentasToolStripMenuItem.DropDownItems(2).Enabled = False
            ComprasToolStripMenuItem.DropDownItems(2).Enabled = False
            ProveedoresToolStripMenuItem.DropDownItems(2).Enabled = False
            ClientesToolStripMenuItem.DropDownItems(2).Enabled = False
            ProductosToolStripMenuItem.DropDownItems(2).Enabled = False
            VentasToolStripMenuItem.DropDownItems(2).Visible = False
            ComprasToolStripMenuItem.DropDownItems(2).Visible = False
            ProveedoresToolStripMenuItem.DropDownItems(2).Visible = False
            ClientesToolStripMenuItem.DropDownItems(2).Visible = False
            ProductosToolStripMenuItem.DropDownItems(2).Visible = False
            OpcionesToolStripMenuItem.DropDownItems(1).Enabled = False
            OpcionesToolStripMenuItem.DropDownItems(3).Enabled = False
            OpcionesToolStripMenuItem.DropDownItems(1).Visible = False
            OpcionesToolStripMenuItem.DropDownItems(3).Visible = False
        ElseIf Usuario.propTipo.Equals("Empleado") Then
            VentasToolStripMenuItem.DropDownItems(2).Enabled = False
            ComprasToolStripMenuItem.DropDownItems(2).Enabled = False
            ProveedoresToolStripMenuItem.DropDownItems(2).Enabled = False
            ClientesToolStripMenuItem.DropDownItems(2).Enabled = False
            ProductosToolStripMenuItem.DropDownItems(2).Enabled = False
            VentasToolStripMenuItem.DropDownItems(2).Visible = False
            ComprasToolStripMenuItem.DropDownItems(2).Visible = False
            ProveedoresToolStripMenuItem.DropDownItems(2).Visible = False
            ClientesToolStripMenuItem.DropDownItems(2).Visible = False
            ProductosToolStripMenuItem.DropDownItems(2).Visible = False
            VentasToolStripMenuItem.DropDownItems(3).Enabled = False
            ComprasToolStripMenuItem.DropDownItems(3).Enabled = False
            ProveedoresToolStripMenuItem.DropDownItems(3).Enabled = False
            ClientesToolStripMenuItem.DropDownItems(3).Enabled = False
            ProductosToolStripMenuItem.DropDownItems(3).Enabled = False
            VentasToolStripMenuItem.DropDownItems(3).Visible = False
            ComprasToolStripMenuItem.DropDownItems(3).Visible = False
            ProveedoresToolStripMenuItem.DropDownItems(3).Visible = False
            ClientesToolStripMenuItem.DropDownItems(3).Visible = False
            ProductosToolStripMenuItem.DropDownItems(3).Visible = False
            OpcionesToolStripMenuItem.DropDownItems(1).Enabled = False
            OpcionesToolStripMenuItem.DropDownItems(3).Enabled = False
            OpcionesToolStripMenuItem.DropDownItems(1).Visible = False
            OpcionesToolStripMenuItem.DropDownItems(3).Visible = False
        End If
    End Sub

    Private Sub ListadoToolStripMenuItem4_Click(sender As System.Object, e As System.EventArgs) Handles ListadoToolStripMenuItem4.Click
        If co.Visible = False Or co.IsDisposed Then
            co = New Compras
            co.borrar = True
            co.MdiParent = Me
            co.Show()
        End If
    End Sub

    Private Sub InsertarCompraToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InsertarCompraToolStripMenuItem.Click
        If ic.Visible = False Or ic.IsDisposed Then
            ic = New insertarCompra
            ic.borrar = True
            ic.MdiParent = Me
            ic.Show()
        End If
    End Sub

    Private Sub BorrarCompraToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles BorrarCompraToolStripMenuItem.Click
        If bc.Visible = False Or bc.IsDisposed Then
            bc = New borrarCompras
            bc.borrar = True
            bc.MdiParent = Me
            bc.Show()
        End If
    End Sub

    Private Sub ActualizarCompraToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ActualizarCompraToolStripMenuItem.Click
        If ac.Visible = False Or ac.IsDisposed Then
            ac = New actualizarCompra
            ac.borrar = True
            ac.MdiParent = Me
            ac.Show()
        End If
    End Sub

    Private Sub ListadoToolStripMenuItem3_Click(sender As System.Object, e As System.EventArgs) Handles ListadoToolStripMenuItem3.Click
        If cl.Visible = False Or cl.IsDisposed Then
            cl = New Clientes
            cl.borrar = True
            cl.MdiParent = Me
            cl.Show()
        End If
    End Sub

    Private Sub InsertarClienteToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InsertarClienteToolStripMenuItem.Click
        If icl.Visible = False Or icl.IsDisposed Then
            icl = New insertarCliente
            icl.borrar = True
            icl.MdiParent = Me
            icl.Show()
        End If
    End Sub

    Private Sub BorrarClienteToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles BorrarClienteToolStripMenuItem.Click
        If bcl.Visible = False Or bcl.IsDisposed Then
            bcl = New borrarCliente
            bcl.borrar = True
            bcl.MdiParent = Me
            bcl.Show()
        End If
    End Sub

    Private Sub ListadoToolStripMenuItem2_Click(sender As System.Object, e As System.EventArgs) Handles ListadoToolStripMenuItem2.Click
        If pr.Visible = False Or pr.IsDisposed Then
            pr = New PantallaProductos
            pr.borrar = True
            pr.MdiParent = Me
            pr.Show()
        End If
    End Sub

    Private Sub InsertarProductoToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InsertarProductoToolStripMenuItem.Click
        If ap.Visible = False Or ap.IsDisposed Then
            ap = New AñadirProducto
            ap.borrar = True
            ap.MdiParent = Me
            ap.Show()
        End If
    End Sub

    Private Sub ActualizarProductoToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ActualizarProductoToolStripMenuItem.Click
        If mp.Visible = False Or mp.IsDisposed Then
            mp = New ModificarProducto
            mp.borrar = True
            mp.MdiParent = Me
            mp.Show()
        End If
    End Sub

    Private Sub ListadoToolStripMenuItem1_Click(sender As System.Object, e As System.EventArgs) Handles ListadoToolStripMenuItem1.Click
        If pro.Visible = False Or pro.IsDisposed Then
            pro = New Proveedores
            pro.borrar = True
            pro.MdiParent = Me
            pro.Show()
        End If
    End Sub

    Private Sub InsertarProveedorToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InsertarProveedorToolStripMenuItem.Click
        If ipr.Visible = False Or ipr.IsDisposed Then
            ipr = New insertarProveedor
            ipr.borrar = True
            ipr.MdiParent = Me
            ipr.Show()
        End If
    End Sub

    Private Sub BorrarProveedorToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles BorrarProveedorToolStripMenuItem.Click
        If bpr.Visible = False Or bpr.IsDisposed Then
            bpr = New borrarProveedor
            bpr.borrar = True
            bpr.MdiParent = Me
            bpr.Show()
        End If
    End Sub

    Private Sub ActualizarProveedorToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ActualizarProveedorToolStripMenuItem.Click
        If apr.Visible = False Or apr.IsDisposed Then
            apr = New actualizarProveedor
            apr.borrar = True
            apr.MdiParent = Me
            apr.Show()
        End If
    End Sub
End Class