﻿Imports System.Data.OleDb
Imports System.IO

Module Empresa

    Private _cif As String
    Private _nombre As String
    Private _localidad As String
    Private _provincia As String
    Private _pais As String
    Private _codPostal As String
    Private _sector As String
    Private _rutaImagen As String

    Public Property Cif() As String
        Get
            Return _cif
        End Get
        Set(ByVal value As String)
            _cif = value
        End Set
    End Property

    Public Property Nombre() As String
        Get
            Return _nombre
        End Get
        Set(ByVal value As String)
            _nombre = value
        End Set
    End Property

    Public Property Localidad() As String
        Get
            Return _localidad
        End Get
        Set(ByVal value As String)
            _localidad = value
        End Set
    End Property

    Public Property Provincia() As String
        Get
            Return _provincia
        End Get
        Set(ByVal value As String)
            _provincia = value
        End Set
    End Property

    Public Property Pais() As String
        Get
            Return _pais
        End Get
        Set(ByVal value As String)
            _pais = value
        End Set
    End Property

    Public Property CodPostal() As String
        Get
            Return _codPostal
        End Get
        Set(ByVal value As String)
            _codPostal = value
        End Set
    End Property

    Public Property Sector() As String
        Get
            Return _sector
        End Get
        Set(ByVal value As String)
            _sector = value
        End Set
    End Property

    Public Property RutaImagen() As String
        Get
            Return _rutaImagen
        End Get
        Set(ByVal value As String)
            _rutaImagen = value
        End Set
    End Property

    Sub elm()
        Dim cm As New OleDbCommand("Delete * from empresa where cif = @cif", BD.consConex)
        cm.Parameters.Add("@cif", OleDbType.Char, 9).Value = Empresa.Cif
        cm.ExecuteNonQuery()
        If Not Empresa.RutaImagen.Equals("\Imagenes\Empresas\MAC ERP.jpg") Then
            Try
                File.Delete(Application.StartupPath + Empresa.RutaImagen)
            Catch ie As IOException
            End Try
        End If
    End Sub

    Sub borr(ByVal fr As Form)
        Dim res As DialogResult = MessageBox.Show("¿Está seguro de querer hacerlo, una vez hecho ya no se podra deshacer?", "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)
        If res = Windows.Forms.DialogResult.Yes Then
            elm()
        End If
    End Sub

End Module
