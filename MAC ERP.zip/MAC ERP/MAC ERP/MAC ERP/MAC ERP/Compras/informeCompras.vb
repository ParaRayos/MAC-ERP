﻿Option Strict On
Imports System.Data.OleDb

Public Class informeCompras
    Dim borr As Boolean = False
    Public Property borrar() As Boolean
        Get
            Return borr
        End Get
        Set(ByVal value As Boolean)
            borr = value
        End Set
    End Property
    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim desde As Date
        Dim hasta As Date

        desde = Convert.ToDateTime(txtDesde.Text)
        hasta = Convert.ToDateTime(txtHasta.Text)

        dataSetAlmacen = New DataSet
        dataSetAlmacen.Clear()


        Dim sql As String = "SELECT * FROM compra WHERE fecha >= #" & desde & "# and fecha <=#" & hasta & "#"

        adapCompras = New OleDbDataAdapter(sql, consConex)

        adapCompras.Fill(dataSetAlmacen, tabla1)

        Dim rpt As New informeCompra
        rpt.SetDataSource(dataSetAlmacen)
        Me.CrystalReportViewer1.ReportSource = rpt
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        Compras.Show()
        Me.Close()
    End Sub

    Private Sub informeCompras_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If borr = True Then
            lbAtras.Enabled = False
            lbAtras.Visible = False
            llSalir.Enabled = False
            llSalir.Visible = False
        End If
    End Sub

    Private Sub llSalir_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub
End Class