﻿Public Class CamConLog

    Private Sub cb1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb1.CheckedChanged
        cambConCheck(txtContraseñaAntigua)
    End Sub

    Private Sub cb2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb2.CheckedChanged
        cambConCheck(txtContraseñaNueva1)
    End Sub

    Private Sub cb3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb3.CheckedChanged
        cambConCheck(txtContraseñaNueva2)
    End Sub

    Private Sub btnBorrarCampos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrarCampos.Click
        Contra.borraCampos(txtContraseñaAntigua, txtContraseñaNueva1, txtContraseñaNueva2, cb1, cb2, cb3)
        txtUsu.Text = ""
    End Sub

    Private Sub btnCambiarContraseña_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCambiarContraseña.Click
        If Contra.cambContra(BD.consConex, txtContraseñaAntigua.Text, txtContraseñaNueva1.Text, txtContraseñaNueva2.Text, txtUsu.Text) = True Then
            frmLogin.Show()
            Me.Close()
        End If
    End Sub

    Private Sub lbCer_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbCer.LinkClicked
        desconecta()
        Me.Close()
    End Sub

    Private Sub llLog_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llLog.LinkClicked
        frmLogin.Show()
        Me.Close()
    End Sub
End Class