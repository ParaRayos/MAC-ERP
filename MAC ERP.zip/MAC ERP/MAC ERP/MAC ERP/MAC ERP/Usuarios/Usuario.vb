﻿Imports System.Data.OleDb

Module Usuario
    Private nick As String
    Private passw As String
    Private CIFE As String
    Private Tipo As String

    Public Property propNick() As String
        Get
            Return nick
        End Get
        Set(ByVal value As String)
            nick = value
        End Set
    End Property

    Public Property propPass() As String
        Get
            Return passw
        End Get
        Set(ByVal value As String)
            passw = value
        End Set
    End Property

    Public Property propCIFE() As String
        Get
            Return CIFE
        End Get
        Set(ByVal value As String)
            CIFE = value
        End Set
    End Property

    Public Property propTipo() As String
        Get
            Return Tipo
        End Get
        Set(ByVal value As String)
            Tipo = value
        End Set
    End Property

    Function regisUsu(ByVal tbcon As TextBox, ByVal tbRepCon As TextBox, ByVal tbUsu As TextBox, ByVal tipoUsuario As ComboBox) As Boolean
        Dim sPa As Boolean = True
        If tbcon.Text.Equals("Introduce la contraseña que quieres tener.") Or tbRepCon.Text.Equals("Repite la contraseña que deseas tener.") Or tbUsu.Text.Equals("Introduce el nick de usuario o email a registrar.") Then
            MessageBox.Show("Faltan datos por introducir.", "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error)
            sPa = False
        Else
            If tipoUsuario.Text.Equals("Tipo de Usuario") Then
                MessageBox.Show("No ha seleccionado un tipo de usuario", "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error)
                sPa = False
            Else
                If tbcon.Text.Equals(tbRepCon.Text) Then
                    Dim gr As New OleDbCommand("Insert into usuarios values('" + tbUsu.Text + "','" + tbcon.Text + "','" + Empresa.Cif + "','" + tipoUsuario.Text + "')", BD.consConex)
                    Try
                        gr.ExecuteNonQuery()
                    Catch ex As OleDbException
                        MessageBox.Show("El nick de usuario que ha elegido ya esta registrado.", "Error SQL:", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        sPa = False
                    End Try
                Else
                    MessageBox.Show("Las dos contraseñas introducidas no coinciden.", "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    sPa = False
                End If
            End If
        End If
        Return sPa
    End Function

End Module
