﻿Imports System.Data.OleDb
Imports System.IO
Public Class CrearUsuario
    Dim llama As String
    Public Property lla() As String
        Get
            Return llama
        End Get
        Set(ByVal value As String)
            llama = value
        End Set
    End Property

    Private Sub tbUsu_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tbUsu.GotFocus
        conGFocusUsu(Me.tbUsu, "Introduce el nick de usuario o email a registrar.")
    End Sub

    Private Sub tbCon_GotFocus(sender As Object, e As System.EventArgs) Handles tbCon.GotFocus
        conGFocusCont(Me.tbCon, "Introduce la contraseña que quieres tener.")
    End Sub

    Private Sub tbRepCon_GotFocus(sender As Object, e As System.EventArgs) Handles tbRepCon.GotFocus
        conGFocusCont(Me.tbRepCon, "Repite la contraseña que deseas tener.")
    End Sub

    Private Sub tbUsu_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbUsu.KeyPress, tbCon.KeyPress, tbRepCon.KeyPress
        conTecl(e)
    End Sub

    Private Sub lbAtras_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        If lla.Equals("NEMPRESA") Then
            elm()
            NuevaEmpresa.Show()
            Me.Close()
        Else
            MenuEmpresa.Show()
            Me.Close()
        End If
    End Sub

    Private Sub tbCon_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles tbCon.Validating
        conValiCont(Me.tbCon, Me.cbCon, "Introduce la contraseña que quieres tener.")
        checkMostarCon(Me.tbCon, Me.cbCon, "Introduce la contraseña que quieres tener.")
    End Sub

    Private Sub tbRepCon_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles tbRepCon.Validating
        conValiCont(Me.tbRepCon, Me.cbConD, "Repite la contraseña que deseas tener.")
        checkMostarCon(Me.tbRepCon, Me.cbConD, "Repite la contraseña que deseas tener.")
    End Sub

    Private Sub tbUsu_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles tbUsu.Validating
        conValiUsu(Me.tbUsu, "Introduce el nick de usuario o email a registrar.")
    End Sub

    Private Sub cbCon_CheckedChanged(sender As Object, e As System.EventArgs) Handles cbCon.CheckedChanged
        checkMostarCon(Me.tbCon, Me.cbCon, "Introduce la contraseña que quieres tener.")
    End Sub

    Private Sub cbConD_CheckedChanged(sender As Object, e As System.EventArgs) Handles cbConD.CheckedChanged
        checkMostarCon(Me.tbRepCon, Me.cbConD, "Repite la contraseña que deseas tener.")
    End Sub

    Private Sub CrearUsuario_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        If llama.Equals("NEMPRESA") Then
            tipoUsuario.SelectedIndex = 0
            tipoUsuario.Enabled = False
        Else
            btnFinalizar.Text = "Crear usuario"
            If llama.Equals("EMPRESA") Then
                llSalir.Enabled = False
                llSalir.Visible = False
                Me.ControlBox = True
                lbAtras.Enabled = False
                lbAtras.Visible = False
            Else

            End If
        End If
        lbCrU.Focus()
    End Sub

    Private Sub tipoUsuario_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles tipoUsuario.KeyPress
        e.Handled = True
    End Sub

    Private Sub btnFinalizar_Click(sender As System.Object, e As System.EventArgs) Handles btnFinalizar.Click
        If regisUsu(tbCon, tbRepCon, tbUsu, tipoUsuario) Then
            MessageBox.Show("Creación de la empresa y el usuario del tipo " + tipoUsuario.Text + " de forma correcta.", "Información:", MessageBoxButtons.OK, MessageBoxIcon.Information)
            If llama.Equals("NEMPRESA") Then
                frmLogin.Show()
                Me.Close()
            End If
        End If
    End Sub

    Private Sub llSalir_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        If lla.Equals("NEMPRESA") Then
            elm()
        End If
        desconecta()
        Me.Close()
    End Sub

    Private Sub CrearUsuario_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Not llama.Equals("NEMPRESA") Then
            If Usuario.propTipo.Equals("Supervisor") Then
                tipoUsuario.Items.Remove("Administrador")
            ElseIf Usuario.propTipo.Equals("Empleado") Then
                tipoUsuario.Items.Remove("Administrador")
                tipoUsuario.Items.Remove("Supervisor")
            End If
        End If
    End Sub
End Class