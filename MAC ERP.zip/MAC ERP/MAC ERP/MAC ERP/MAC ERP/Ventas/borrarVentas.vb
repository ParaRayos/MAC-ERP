﻿Option Strict On
Imports System.Data.OleDb

Public Class borrarVentas
    Dim borr As Boolean = False
    Public Property borrar() As Boolean
        Get
            Return borr
        End Get
        Set(ByVal value As Boolean)
            borr = value
        End Set
    End Property
    Public Sub enlazarDatos()
        bindingVentas.DataSource = dataSetAlmacen
        bindingVentas.DataMember = tabla2
        Me.txtFecha.DataBindings.Add(New Binding("Text", bindingVentas, "FECHA", True))
        Me.txtIdArticulo.DataBindings.Add(New Binding("Text", bindingVentas, "ID_ARTICULO", True))
        Me.txtCantidad.DataBindings.Add(New Binding("Text", bindingVentas, "CANTIDAD", True))
        Me.txtImporteTotal.DataBindings.Add(New Binding("Text", bindingVentas, "IMPORTE_TOTAL", True))
        Me.txtComprador.DataBindings.Add(New Binding("Text", bindingVentas, "COMPRADOR", True))
    End Sub

    Sub buscar()
        Dim pedido As Integer
        Dim linea_pedido As Integer

        If txtPedido.Text = "" Or txtLineaPedido.Text = "" Then
            MessageBox.Show("Introduzca todos los datos por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select * from venta where pedido =@pedido and linea_pedido = @linea", consConex)

            comando.Parameters.Add("@pedido", OleDbType.Integer, 6).Value = CInt(Me.txtPedido.Text())
            comando.Parameters.Add("@linea", OleDbType.Integer, 3).Value = txtLineaPedido.Text

            adapVentas = New OleDbDataAdapter(comando)
            adapVentas.Fill(dataSetAlmacen, tabla2)

            Try
                Dim fila As DataRow
                Dim fila2 As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)
                fila2 = dataSetAlmacen.Tables(0).Rows(0)

                pedido = CInt(fila("PEDIDO"))
                linea_pedido = CInt(fila2("LINEA_PEDIDO"))

                Me.btnEliminar.Enabled = True
                Me.btnLimpiar.Enabled = True
                Me.btnBuscar.Visible = False
                Me.txtPedido.Enabled = False
                Me.txtLineaPedido.Enabled = False

                enlazarDatos()
            Catch ex As IndexOutOfRangeException
                MessageBox.Show("No existe ninguna venta con esos datos.")
            End Try
        End If
    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        buscar()
    End Sub

    Public Sub limpiar()
        Dim frm As New borrarVentas

        frm.Show()
        Me.Close()

    End Sub

    Sub eliminar()
        Dim eliminar As New OleDbCommand("DELETE FROM venta WHERE pedido = @pedido AND linea_pedido = @linea", consConex)
        eliminar.Parameters.Add("@pedido", OleDbType.Integer, 6).Value = CInt(Me.txtPedido.Text())
        eliminar.Parameters.Add("@linea", OleDbType.Integer, 3).Value = txtLineaPedido.Text

        Dim j As Integer = eliminar.ExecuteNonQuery()
        If j > 0 Then
            MessageBox.Show("Venta eliminada")
            limpiar()
        End If
    End Sub

    Private Sub btnLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        eliminar()
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked
        Ventas.Show()

        Me.Close()

    End Sub

    Private Sub llSalir_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSalir.LinkClicked
        desconecta()
        Me.Close()
    End Sub

    Private Sub borrarVentas_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If borr = True Then
            lbAtras.Enabled = False
            lbAtras.Visible = False
            llSalir.Enabled = False
            llSalir.Visible = False
        End If
    End Sub
End Class