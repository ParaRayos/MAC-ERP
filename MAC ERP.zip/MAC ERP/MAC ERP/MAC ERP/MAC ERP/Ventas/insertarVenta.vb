﻿Option Strict On
Imports System.Data.OleDb

Public Class insertarVenta
    Dim borr As Boolean = False
    Public Property borrar() As Boolean
        Get
            Return borr
        End Get
        Set(ByVal value As Boolean)
            borr = value
        End Set
    End Property

    Public Sub mostrar()
        btnInsertar.Enabled = True
        txtFecha.Enabled = True
        txtCantidad.Enabled = True
        txtImporteTotal.Enabled = True
        txtComprador.Enabled = True
    End Sub

    Public Sub ocultar()
        txtFecha.Enabled = False
        txtCantidad.Enabled = False
        txtImporteTotal.Enabled = False
        txtComprador.Enabled = False
    End Sub

    Public Sub limpiar()
        txtPedido.Text = ""
        txtLineaPedido.Text = ""
        txtIdArticulo.Text = ""
        txtFecha.Text = ""
        txtCantidad.Text = ""
        txtComprador.Text = ""
        txtImporteTotal.Text = ""
        txtIdArticulo.Enabled = False
        btnInsertar.Enabled = False
        btnValidar.Visible = True
        btnValidar2.Visible = False
    End Sub

    Public Sub validarCompra()
        Dim pedido As Integer
        Dim cif As String
        Dim linea As Integer
        If txtPedido.Text = "" Or txtLineaPedido.Text = "" Then
            MessageBox.Show("Introduzca los datos por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select * from venta where pedido =@pedido and cif_empresa = @cif and linea_pedido = @linea", consConex)

            comando.Parameters.Add("@pedido", OleDbType.Integer, 6).Value = Me.txtPedido.Text
            comando.Parameters.Add("@cif", OleDbType.Char, 9).Value = Empresa.Cif
            comando.Parameters.Add("@linea", OleDbType.Integer, 3).Value = Me.txtLineaPedido.Text

            adapVentas = New OleDbDataAdapter(comando)
            adapVentas.Fill(dataSetAlmacen, tabla2)

            Try
                Dim fila As DataRow
                Dim fila2 As DataRow
                Dim fila3 As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)
                fila2 = dataSetAlmacen.Tables(0).Rows(0)
                fila3 = dataSetAlmacen.Tables(0).Rows(0)

                pedido = CInt(fila("PEDIDO"))
                cif = CStr(fila2("CIF_EMPRESA"))
                linea = CInt(fila3("LINEA_PEDIDO"))

                MessageBox.Show("Ya existe una venta con esos datos.")
            Catch ex As IndexOutOfRangeException
                btnValidar2.Visible = True
                txtIdArticulo.Enabled = True
                btnValidar.Visible = False
            End Try
        End If
    End Sub

    Public Sub validarArticulo()
        Dim articulo As Integer
        If txtIdArticulo.Text = "" Then
            MessageBox.Show("Introduzca el id del artículo por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select cod_articulo from productos where cod_articulo =@articulo ", consConex)

            comando.Parameters.Add("@articulo", OleDbType.Integer, 4).Value = Me.txtIdArticulo.Text

            adapVentas = New OleDbDataAdapter(comando)
            adapVentas.Fill(dataSetAlmacen, tabla0)

            Try
                Dim fila As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)

                articulo = CInt(fila("COD_ARTICULO"))

                mostrar()
                btnValidar2.Visible = False
            Catch ex As IndexOutOfRangeException
                MessageBox.Show("No existe ningún artículo con ese código.")
            End Try
        End If
    End Sub

    Private Sub btnValidar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValidar.Click
        validarCompra()
    End Sub

    Private Sub btnValidar2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValidar2.Click
        validarArticulo()
    End Sub


    Private Sub txtPedido_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPedido.TextChanged, txtLineaPedido.TextChanged
        ocultar()
        txtIdArticulo.Enabled = False
        btnValidar2.Visible = False
        btnValidar.Visible = True
    End Sub

    Private Sub txtIdArticulo_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtIdArticulo.TextChanged
        ocultar()
        btnValidar2.Visible = True
    End Sub

    Private Sub txtCantidad_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtCantidad.Validating
        Dim precio As Double
        Dim importeTotal As Double
        Dim tablaProductos As New DataTable
        Dim existencias As Integer

        Dim sql As String = "SELECT existencias from productos where cod_articulo = ? and cif_empresa = '" & Empresa.Cif & "' "
        Using com = New OleDbCommand(sql, consConex)
            com.Parameters.AddWithValue("@p1", Convert.ToInt16(txtIdArticulo.Text))
            existencias = CInt(com.ExecuteScalar())
        End Using

        If (existencias - CDbl(txtCantidad.Text)) < 0 Then
            txtCantidad.Text = ""
            txtCantidad.Focus()
            MessageBox.Show("No hay disponible tantas existencias de ese producto. Introduzca una cantidad menor")
        Else
            Dim sql2 As String = "SELECT precio from productos where cod_articulo = ? and cif_empresa = '" & Empresa.Cif & "' "
            Using comando = New OleDbCommand(sql2, consConex)
                comando.Parameters.AddWithValue("@p1", Convert.ToInt16(txtIdArticulo.Text))
                precio = CDbl(comando.ExecuteScalar())
            End Using

            If txtCantidad.Text <> "" Then
                importeTotal = precio * CDbl(txtCantidad.Text)
                txtImporteTotal.Text = CStr(importeTotal)
            Else
                txtImporteTotal.Text = ""
            End If
        End If
    End Sub

    Public Sub insertar()
        Try
            Dim insertar As New OleDbCommand("INSERT INTO venta(pedido, cif_empresa, linea_pedido, fecha, id_articulo, cantidad, importe_total, comprador) values(@pedido, @cif, @linea_pedido, @fecha, @id_articulo, @cantidad, @importe_total, @comprador)", consConex)
            insertar.Parameters.Add("@pedido", OleDbType.Integer, 6).Value = CInt(Me.txtPedido.Text())
            insertar.Parameters.Add("@cif", OleDbType.Char, 9).Value = Empresa.Cif
            insertar.Parameters.Add("@linea_pedido", OleDbType.Integer, 3).Value = txtLineaPedido.Text
            insertar.Parameters.Add("@fecha", OleDbType.Date).Value = txtFecha.Text
            insertar.Parameters.Add("@id_articulo", OleDbType.Integer, 4).Value = txtIdArticulo.Text
            insertar.Parameters.Add("@cantidad", OleDbType.Integer, 3).Value = txtCantidad.Text
            insertar.Parameters.Add("@importe_total", OleDbType.Double, 6).Value = txtImporteTotal.Text
            insertar.Parameters.Add("@comprador", OleDbType.Integer, 4).Value = txtComprador.Text

            Dim j As Integer = insertar.ExecuteNonQuery()
            actualizarExistencias()
            If j > 0 Then
                MessageBox.Show("Venta insertada")
            End If
        Catch ex As FormatException
            MessageBox.Show("Inserte todos los campos")
        End Try
    End Sub


    Private Sub btnInsertar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsertar.Click
        insertar()
        limpiar()
        ocultar()
    End Sub

    Public Sub actualizarExistencias()
        Dim existencias As Integer

        Dim tablaProductos As New DataTable
        Dim sql As String = "SELECT existencias from productos where cod_articulo = ? and cif_empresa = '" & Empresa.Cif & "' "
        Using comando = New OleDbCommand(sql, consConex)
            comando.Parameters.AddWithValue("@p1", Convert.ToInt16(txtIdArticulo.Text))
            existencias = CInt(comando.ExecuteScalar())
        End Using

        existencias = CInt(existencias - CDbl(txtCantidad.Text))

        Dim sql2 As String = "UPDATE productos SET existencias =? WHERE cod_articulo = ? and cif_empresa = '" & Empresa.Cif & "'"
        Using act = New OleDbCommand(sql2, consConex)
            act.Parameters.AddWithValue("@p1", existencias)
            act.Parameters.AddWithValue("@p2", Convert.ToInt16(txtIdArticulo.Text))
            act.ExecuteNonQuery()
        End Using
    End Sub

    Private Sub lbAtras_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbAtras.LinkClicked

        Ventas.Show()
        Me.Close()

    End Sub

    Private Sub insertarVenta_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If borr = True Then
            lbAtras.Enabled = False
            lbAtras.Visible = False
            llSalir.Enabled = False
            llSalir.Visible = False
        End If
    End Sub
End Class