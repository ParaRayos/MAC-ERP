﻿Option Strict On
Imports System.Data.OleDb


Public Class actualizarProveedor

    Public Sub mostrar()
        txtCif.Enabled = True
        txtNombre.Enabled = True
        txtApellidos.Enabled = True
        txtDireccion.Enabled = True
        txtLocalidad.Enabled = True
        txtProvincia.Enabled = True
        txtPais.Enabled = True
        txtParticular.Enabled = True
        txtEmpresa.Enabled = True
        txtFijo.Enabled = True
        txtMovil.Enabled = True
        txtEmail.Enabled = True
        btnActualizar.Enabled = True

        txtProveedor.Enabled = False
        txtCif.Enabled = False
        btnBuscar.Visible = False
    End Sub

    Public Sub enlazarDatos()
        bindingProveedores.DataSource = dataSetAlmacen
        bindingProveedores.DataMember = tabla4
        Me.txtNombre.DataBindings.Add(New Binding("Text", bindingProveedores, "NOMBRE", True))
        Me.txtApellidos.DataBindings.Add(New Binding("Text", bindingProveedores, "APELLIDOS", True))
        Me.txtDireccion.DataBindings.Add(New Binding("Text", bindingProveedores, "DIRECCION", True))
        Me.txtLocalidad.DataBindings.Add(New Binding("Text", bindingProveedores, "LOCALIDAD", True))
        Me.txtProvincia.DataBindings.Add(New Binding("Text", bindingProveedores, "PROVINCIA", True))
        Me.txtPais.DataBindings.Add(New Binding("Text", bindingProveedores, "PAIS", True))
        Me.txtEmpresa.DataBindings.Add(New Binding("Checked", bindingProveedores, "EMPRESA", True))
        Me.txtParticular.DataBindings.Add(New Binding("Checked", bindingProveedores, "PARTICULAR", True))
        Me.txtFijo.DataBindings.Add(New Binding("Text", bindingProveedores, "TELEFONO_FIJO", True))
        Me.txtMovil.DataBindings.Add(New Binding("Text", bindingProveedores, "TELEFONO_MOVIL", True))
        Me.txtEmail.DataBindings.Add(New Binding("Text", bindingProveedores, "EMAIL", True))
    End Sub

    Sub buscar()
        Dim proveedor As Integer
        Dim cif As String

        If txtProveedor.Text = "" Or txtCif.Text = "" Then
            MessageBox.Show("Introduzca todos los datos por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select * from proveedores where id_proveedor =@proveedor and cif = @cif", consConex)

            comando.Parameters.Add("@proveedor", OleDbType.Integer, 4).Value = Me.txtProveedor.Text
            comando.Parameters.Add("@cif", OleDbType.Char, 9).Value = Me.txtCif.Text

            adapClientes = New OleDbDataAdapter(comando)
            adapClientes.Fill(dataSetAlmacen, tabla4)

            Try
                Dim fila As DataRow
                Dim fila2 As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)
                fila2 = dataSetAlmacen.Tables(0).Rows(0)

                proveedor = CInt(fila("ID_PROVEEDOR"))
                cif = CStr(fila2("CIF"))

                Me.btnActualizar.Enabled = True
                Me.btnLimpiar.Enabled = True
                enlazarDatos()
                mostrar()
            Catch ex As IndexOutOfRangeException
                MessageBox.Show("No existe ningún proveedor con esos datos.")
            End Try
        End If
    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        buscar()
    End Sub

    Public Sub limpiar()
        Me.Close()
        Dim frm As New actualizarProveedor

        frm.Show()
    End Sub

    Private Sub btnLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Public Sub actualizar()
        Dim sql As String = "UPDATE proveedores SET nombre =?, apellidos =?, direccion =?, localidad =?, provincia =?, pais =?, telefono_fijo =?, telefono_movil =?, email =? WHERE id_proveedor = ? and cif = ?"
        Using actualizar = New OleDbCommand(sql, consConex)
            actualizar.Parameters.AddWithValue("@p1", txtNombre.Text)
            actualizar.Parameters.AddWithValue("@p2", txtApellidos.Text)
            actualizar.Parameters.AddWithValue("@p3", txtDireccion.Text)
            actualizar.Parameters.AddWithValue("@p4", txtLocalidad.Text)
            actualizar.Parameters.AddWithValue("@p5", txtProvincia.Text)
            actualizar.Parameters.AddWithValue("@p6", txtPais.Text)
            actualizar.Parameters.AddWithValue("@p7", Convert.ToInt64(txtFijo.Text))
            actualizar.Parameters.AddWithValue("@p8", Convert.ToInt64(txtMovil.Text))
            actualizar.Parameters.AddWithValue("@p9", txtEmail.Text)
            actualizar.Parameters.AddWithValue("@p10", Convert.ToInt16(txtProveedor.Text))
            actualizar.Parameters.AddWithValue("@p11", txtCif.Text)
            If txtEmpresa.Checked Then
                Dim sql2 As String = "UPDATE proveedores SET empresa =? WHERE id_proveedor = ? and cif = ?"
                Using act = New OleDbCommand(sql2, consConex)
                    act.Parameters.AddWithValue("@p1", txtEmpresa.Checked)
                    act.Parameters.AddWithValue("@p2", Convert.ToInt16(txtProveedor.Text))
                    act.Parameters.AddWithValue("@p3", txtCif.Text)
                    act.ExecuteNonQuery()
                End Using

            Else
                Dim sql2 As String = "UPDATE proveedores SET empresa =? WHERE id_proveedor = ? and cif = ?"
                Using act = New OleDbCommand(sql2, consConex)
                    act.Parameters.AddWithValue("@p1", txtEmpresa.CheckState)
                    act.Parameters.AddWithValue("@p2", Convert.ToInt16(txtProveedor.Text))
                    act.Parameters.AddWithValue("@p3", txtCif.Text)
                    act.ExecuteNonQuery()
                End Using
            End If

            If txtParticular.Checked Then
                Dim sql2 As String = "UPDATE proveedores SET particular =? WHERE id_proveedor = ? and cif = ?"
                Using act = New OleDbCommand(sql2, consConex)
                    act.Parameters.AddWithValue("@p1", txtParticular.Checked)
                    act.Parameters.AddWithValue("@p2", Convert.ToInt16(txtProveedor.Text))
                    act.Parameters.AddWithValue("@p3", txtCif.Text)
                    act.ExecuteNonQuery()
                End Using

            Else
                Dim sql2 As String = "UPDATE proveedores SET particular =? WHERE id_proveedor = ? and cif = ?"
                Using act = New OleDbCommand(sql2, consConex)
                    act.Parameters.AddWithValue("@p1", txtParticular.CheckState)
                    act.Parameters.AddWithValue("@p2", Convert.ToInt16(txtProveedor.Text))
                    act.Parameters.AddWithValue("@p3", txtCif.Text)
                    act.ExecuteNonQuery()
                End Using
            End If
            actualizar.ExecuteNonQuery()
        End Using
    End Sub

    Private Sub btnActualizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnActualizar.Click
        actualizar()
        limpiar()
    End Sub
End Class