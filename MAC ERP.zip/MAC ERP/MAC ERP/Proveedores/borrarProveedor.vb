﻿Option Strict On
Imports System.Data.OleDb

Public Class borrarProveedor

    Public Sub enlazarDatos()
        bindingProveedores.DataSource = dataSetAlmacen
        bindingProveedores.DataMember = tabla4
        Me.txtNombre.DataBindings.Add(New Binding("Text", bindingProveedores, "NOMBRE", True))
        Me.txtApellidos.DataBindings.Add(New Binding("Text", bindingProveedores, "APELLIDOS", True))
        Me.txtDireccion.DataBindings.Add(New Binding("Text", bindingProveedores, "DIRECCION", True))
        Me.txtLocalidad.DataBindings.Add(New Binding("Text", bindingProveedores, "LOCALIDAD", True))
        Me.txtProvincia.DataBindings.Add(New Binding("Text", bindingProveedores, "PROVINCIA", True))
        Me.txtPais.DataBindings.Add(New Binding("Text", bindingProveedores, "PAIS", True))
        Me.txtEmpresa.DataBindings.Add(New Binding("Checked", bindingProveedores, "EMPRESA", True))
        Me.txtParticular.DataBindings.Add(New Binding("Checked", bindingProveedores, "PARTICULAR", True))
        Me.txtFijo.DataBindings.Add(New Binding("Text", bindingProveedores, "TELEFONO_FIJO", True))
        Me.txtMovil.DataBindings.Add(New Binding("Text", bindingProveedores, "TELEFONO_MOVIL", True))
        Me.txtEmail.DataBindings.Add(New Binding("Text", bindingProveedores, "EMAIL", True))
    End Sub

    Sub buscar()
        Dim proveedor As Integer
        Dim cif As String

        If txtProveedor.Text = "" Or txtCif.Text = "" Then
            MessageBox.Show("Introduzca todos los datos por favor", "Campos no introducidos", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            dataSetAlmacen = New DataSet
            dataSetAlmacen.Clear()
            comando = New OleDbCommand("Select * from proveedores where id_proveedor =@proveedor and cif = @cif", consConex)

            comando.Parameters.Add("@proveedor", OleDbType.Integer, 4).Value = Me.txtProveedor.Text
            comando.Parameters.Add("@cif", OleDbType.Char, 9).Value = Me.txtCif.Text

            adapProveedores = New OleDbDataAdapter(comando)
            adapProveedores.Fill(dataSetAlmacen, tabla4)

            Try
                Dim fila As DataRow
                Dim fila2 As DataRow

                fila = dataSetAlmacen.Tables(0).Rows(0)
                fila2 = dataSetAlmacen.Tables(0).Rows(0)

                proveedor = CInt(fila("ID_PROVEEDOR"))
                cif = CStr(fila2("CIF_EMPRESA"))

                Me.btnEliminar.Enabled = True
                Me.btnLimpiar.Enabled = True
                enlazarDatos()
            Catch ex As IndexOutOfRangeException
                MessageBox.Show("No existe ningún proveedor con esos datos.")
            End Try
        End If
    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        buscar()
    End Sub

    Public Sub limpiar()
        Me.Close()
        Dim frm As New borrarProveedor

        frm.Show()
    End Sub

    Sub eliminar()
        Dim eliminar As New OleDbCommand("DELETE FROM proveedores WHERE id_proveedor = @proveedor AND cif = @cif", consConex)
        eliminar.Parameters.Add("@proveedor", OleDbType.Integer, 4).Value = Me.txtProveedor.Text
        eliminar.Parameters.Add("@cif", OleDbType.Char, 9).Value = txtCif.Text

        Dim j As Integer = eliminar.ExecuteNonQuery()
        If j > 0 Then
            MessageBox.Show("Proveedor eliminado")
            limpiar()
        End If
    End Sub

    Private Sub btnLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        eliminar()
    End Sub

    Private Sub borrarProveedor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class