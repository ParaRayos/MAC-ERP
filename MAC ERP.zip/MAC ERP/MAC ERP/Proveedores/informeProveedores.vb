﻿Imports System.Data.OleDb

Public Class informeProveedores

    Private Sub informeProveedores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dataSetAlmacen = New DataSet
        dataSetAlmacen.Clear()
        Dim sql As String = "SELECT * FROM proveedores WHERE cif_empresa = '" & Empresa.Cif & "'"

        adapProveedores = New OleDbDataAdapter(sql, consConex)

        adapProveedores.Fill(dataSetAlmacen, tabla4)

        Dim rpt As New informeProveedor
        rpt.SetDataSource(dataSetAlmacen)
        Me.CrystalReportViewer1.ReportSource = rpt
    End Sub
End Class