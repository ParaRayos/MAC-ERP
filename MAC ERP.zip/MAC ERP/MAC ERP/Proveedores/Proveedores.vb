﻿Imports System.Data.OleDb

Public Class Proveedores

    Private Sub btnInsertar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsertar.Click
        insertarProveedor.Show()
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        borrarProveedor.Show()
    End Sub

    Private Sub btnActualizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnActualizar.Click
        actualizarProveedor.Show()
    End Sub

    Private Sub btnInforme_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInforme.Click
        informeProveedores.Show()
    End Sub

    Private Sub dgvProveedores_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvProveedores.CellContentClick

    End Sub

    Private Sub Proveedores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim tablaproveedores As New DataTable
        Dim sql As String = "SELECT * FROM " & tabla4
        adapProveedores = New OleDbDataAdapter(sql, consConex)
        adapProveedores.Fill(tablaproveedores)
        Me.dgvProveedores.DataSource = tablaproveedores
    End Sub
End Class