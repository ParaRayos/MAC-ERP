﻿Public Class MenEmMDI
    Dim pr As New PantallaProductos
    Dim co As New Compras
    Dim cc As New CambiarContraseña
    Dim ve As New Ventas
    Dim cl As New Clientes
    Dim em As New MenuEmpresa
    Dim cU As New CrearUsuario
    Private Sub ProductosToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ProductosToolStripMenuItem.Click
        If pr.Visible = False Or pr.IsDisposed Then
            pr = New PantallaProductos
            pr.MdiParent = Me
            pr.Show()
        End If
    End Sub

    Private Sub ComprasToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ComprasToolStripMenuItem.Click
        If co.Visible = False Or co.IsDisposed Then
            co = New Compras
            co.MdiParent = Me
            co.Show()
        End If
    End Sub

    Private Sub CambiarContraseñaToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CambiarContraseñaToolStripMenuItem.Click
        If cc.Visible = False Or cc.IsDisposed Then
            cc = New CambiarContraseña
            cc.llama = "MDI"
            cc.MdiParent = Me
            cc.Show()
        End If
    End Sub

    Private Sub VentasToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles VentasToolStripMenuItem.Click
        If ve.Visible = False Or ve.IsDisposed Then
            ve = New Ventas
            ve.MdiParent = Me
            ve.Show()
        End If
    End Sub

    Private Sub BorrarEmpresaToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles BorrarEmpresaToolStripMenuItem.Click
        If em.Visible = True Or em.IsDisposed = False Then
            em.Close()
            em.Dispose()
        End If
        borr(Me)
    End Sub

    Private Sub ClientesToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ClientesToolStripMenuItem.Click
        If cl.Visible = False Or cl.IsDisposed Then
            cl = New Clientes
            cl.MdiParent = Me
            cl.Show()
        End If
    End Sub

    Private Sub ModificarDatosDeLaEmpresaToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ModificarDatosDeLaEmpresaToolStripMenuItem.Click
        If em.Visible = False Or em.IsDisposed Then
            em = New MenuEmpresa
            em.btnAlmacen.Enabled = False
            em.btnAlmacen.Visible = False
            em.btnClientes.Enabled = False
            em.btnClientes.Visible = False
            em.btnCompras.Enabled = False
            em.btnCompras.Visible = False
            em.btnProveedores.Enabled = False
            em.btnProveedores.Visible = False
            em.btnVentas.Enabled = False
            em.btnVentas.Visible = False
            em.llCerr.Enabled = False
            em.llCerr.Visible = False
            em.lbOpciones.Enabled = False
            em.lbOpciones.Visible = False
            em.MdiParent = Me
            em.Show()
        End If
    End Sub

    Private Sub InsertarUsuarioToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InsertarUsuarioToolStripMenuItem.Click
        If cU.Visible = False Or cU.IsDisposed Then
            cU = New CrearUsuario
            cU.lla = "EMPRESA"
            cU.MdiParent = Me
            cU.Dock = DockStyle.Fill
            cU.Show()
        End If
    End Sub
End Class