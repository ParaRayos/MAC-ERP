﻿Imports System.Data.OleDb

Public Class Clientes

    Private Sub btnInsertar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsertar.Click
        insertarCliente.Show()
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        borrarCliente.Show()
    End Sub

    Private Sub btnActualizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnActualizar.Click
        actualizarCliente.Show()
    End Sub

    Private Sub btnInforme_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInforme.Click
        informeClientes.Show()
    End Sub

    Private Sub Clientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim tablaClientes As New DataTable
        Dim sql As String = "SELECT * FROM " & tabla3
        adapClientes = New OleDbDataAdapter(sql, consConex)
        adapClientes.Fill(tablaClientes)
        Me.dgvClientes.DataSource = tablaClientes
    End Sub
End Class