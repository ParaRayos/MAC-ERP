﻿Imports System.Data.OleDb

Module BD
    Dim conex As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=proyecto.accdb")

    Sub conecta()
        If conex.State = ConnectionState.Closed Then
            conex.Open()
        End If
    End Sub

    Sub desconecta()
        If conex.State = ConnectionState.Open Then
            conex.Close()
        End If
    End Sub
    Public ReadOnly Property consConex() As OleDbConnection
        Get
            Return conex
        End Get
    End Property

End Module
