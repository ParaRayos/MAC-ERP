﻿Imports System.IO

Public Class NuevaEmpresa
    Dim puedeGrabar As Boolean = False

    Private Sub btnBorrarCajas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrarCajas.Click
        txtCif.Text = ""
        txtNombre.Text = ""
        txtLocalidad.Text = ""
        txtProvincia.Text = ""
        txtPais.Text = ""
        txtCodPostal.Text = ""
        txtSector.Text = ""
    End Sub

    Private Sub recogerDatos()
        comprobarCampos()
        If puedeGrabar Then
            empresa.Cif = txtCif.Text
            empresa.Nombre = txtNombre.Text
            empresa.Localidad = txtLocalidad.Text
            empresa.Provincia = txtProvincia.Text
            empresa.Pais = txtPais.Text
            empresa.CodPostal = txtCodPostal.Text
            empresa.Sector = txtSector.Text
        End If
    End Sub

    Private Sub btnCrearEmpresa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCrearEmpresa.Click
        recogerDatos()
        If puedeGrabar Then
            Dim sql As String = "Insert into Empresa values('" + empresa.Cif + "','" + empresa.Nombre + "','" + empresa.Localidad + "','" + empresa.Provincia + "','" + empresa.Pais + "','" + empresa.CodPostal + "','" + empresa.Sector + "')'"
        End If
    End Sub

    Private Sub comprobarCampos()
        If txtCif.Text = "" Or txtNombre.Text = "" Or txtLocalidad.Text = "" Or txtProvincia.Text = "" Or txtPais.Text = "" Or txtCodPostal.Text = "" Or txtSector.Text = "" Then
            MessageBox.Show("Faltan campos por completar", "INFORMACION", MessageBoxButtons.OK)
        Else
            puedeGrabar = True
        End If
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbImagen.Click
        Dim openFileDialog1 As New OpenFileDialog()
        Dim folder As String = Path.Combine(Application.StartupPath, "Imagenes\Empresas")


        If (Not Directory.Exists(folder)) Then
            Directory.CreateDirectory(folder)
        End If

        openFileDialog1.InitialDirectory = "c:\"
        openFileDialog1.Filter = "Archivos jpeg (*.jpeg)|*.jpeg|Todos los archivos (*.*)|*.*"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True

        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            If openFileDialog1.FileName <> "" Then
                pbImagen.Image = Image.FromFile(openFileDialog1.FileName)
                guaIma(pbImagen, folder, openFileDialog1.SafeFileName)
            End If
        End If
    End Sub

    Sub guaIma(ByVal pb As PictureBox, ByVal ru As String, ByVal arc As String)
        Dim fileName As String = ru + "\" + arc
        If System.IO.File.Exists(fileName) Then
            Dim arS() As String = Split(arc, CChar("."))
            arS(0) = arS(0) + "1"
            arc = arS(0) + "." + arS(1)
            guaIma(pb, ru, arc)
        Else
            pbImagen.Image.Save(fileName, System.Drawing.Imaging.ImageFormat.Jpeg)
        End If
    End Sub
End Class