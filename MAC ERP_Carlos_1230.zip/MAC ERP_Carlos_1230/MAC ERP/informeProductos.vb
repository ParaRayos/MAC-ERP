﻿Public Class informeProductos

    '  Private Sub informeProductos_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    'Dim ds As New proyectoDataSet
    ' Dim ad As New proyectoDataSetTableAdapters.PRODUCTOSTableAdapter
    '    ad.Fill(ds.PRODUCTOS)
    'Dim rpt As New informeProductos
    '    rpt.SetDataSource(ds)
    '    Me.visor.ReportSource = rpt
    ' End Sub
End Class