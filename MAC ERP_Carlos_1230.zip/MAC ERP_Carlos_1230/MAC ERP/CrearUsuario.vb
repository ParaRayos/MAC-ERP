﻿Public Class CrearUsuario

    Private Sub tbUsu_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tbUsu.GotFocus
        conGFocusUsu(Me.tbUsu, "Introduce el nick de usuario o email a registrar.")
    End Sub

    Private Sub tbUsu_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbUsu.KeyPress, tbCon.KeyPress, tbRepCon.KeyPress
        conTecl(e)
    End Sub
End Class