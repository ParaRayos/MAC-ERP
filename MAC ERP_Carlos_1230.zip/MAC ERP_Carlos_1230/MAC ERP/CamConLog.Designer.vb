﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CamConLog
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cb3 = New System.Windows.Forms.CheckBox()
        Me.cb2 = New System.Windows.Forms.CheckBox()
        Me.cb1 = New System.Windows.Forms.CheckBox()
        Me.btnBorrarCampos = New System.Windows.Forms.Button()
        Me.btnCambiarContraseña = New System.Windows.Forms.Button()
        Me.txtContraseñaNueva2 = New System.Windows.Forms.TextBox()
        Me.txtContraseñaNueva1 = New System.Windows.Forms.TextBox()
        Me.txtContraseñaAntigua = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtUsu = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cb3
        '
        Me.cb3.AutoSize = True
        Me.cb3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb3.Location = New System.Drawing.Point(317, 259)
        Me.cb3.Name = "cb3"
        Me.cb3.Size = New System.Drawing.Size(135, 19)
        Me.cb3.TabIndex = 6
        Me.cb3.Text = "Mostrar contraseña."
        Me.cb3.UseVisualStyleBackColor = True
        '
        'cb2
        '
        Me.cb2.AutoSize = True
        Me.cb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb2.Location = New System.Drawing.Point(317, 197)
        Me.cb2.Name = "cb2"
        Me.cb2.Size = New System.Drawing.Size(135, 19)
        Me.cb2.TabIndex = 4
        Me.cb2.Text = "Mostrar contraseña."
        Me.cb2.UseVisualStyleBackColor = True
        '
        'cb1
        '
        Me.cb1.AutoSize = True
        Me.cb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb1.Location = New System.Drawing.Point(317, 137)
        Me.cb1.Name = "cb1"
        Me.cb1.Size = New System.Drawing.Size(135, 19)
        Me.cb1.TabIndex = 2
        Me.cb1.Text = "Mostrar contraseña."
        Me.cb1.UseVisualStyleBackColor = True
        '
        'btnBorrarCampos
        '
        Me.btnBorrarCampos.Location = New System.Drawing.Point(91, 288)
        Me.btnBorrarCampos.Name = "btnBorrarCampos"
        Me.btnBorrarCampos.Size = New System.Drawing.Size(153, 23)
        Me.btnBorrarCampos.TabIndex = 8
        Me.btnBorrarCampos.Text = "Borrar Campos"
        Me.btnBorrarCampos.UseVisualStyleBackColor = True
        '
        'btnCambiarContraseña
        '
        Me.btnCambiarContraseña.Location = New System.Drawing.Point(317, 288)
        Me.btnCambiarContraseña.Name = "btnCambiarContraseña"
        Me.btnCambiarContraseña.Size = New System.Drawing.Size(170, 23)
        Me.btnCambiarContraseña.TabIndex = 7
        Me.btnCambiarContraseña.Text = "Cambiar Contraseña"
        Me.btnCambiarContraseña.UseVisualStyleBackColor = True
        '
        'txtContraseñaNueva2
        '
        Me.txtContraseñaNueva2.Location = New System.Drawing.Point(317, 233)
        Me.txtContraseñaNueva2.Name = "txtContraseñaNueva2"
        Me.txtContraseñaNueva2.Size = New System.Drawing.Size(170, 20)
        Me.txtContraseñaNueva2.TabIndex = 5
        Me.txtContraseñaNueva2.UseSystemPasswordChar = True
        '
        'txtContraseñaNueva1
        '
        Me.txtContraseñaNueva1.Location = New System.Drawing.Point(317, 171)
        Me.txtContraseñaNueva1.Name = "txtContraseñaNueva1"
        Me.txtContraseñaNueva1.Size = New System.Drawing.Size(170, 20)
        Me.txtContraseñaNueva1.TabIndex = 3
        Me.txtContraseñaNueva1.UseSystemPasswordChar = True
        '
        'txtContraseñaAntigua
        '
        Me.txtContraseñaAntigua.Location = New System.Drawing.Point(317, 111)
        Me.txtContraseñaAntigua.Name = "txtContraseñaAntigua"
        Me.txtContraseñaAntigua.Size = New System.Drawing.Size(170, 20)
        Me.txtContraseñaAntigua.TabIndex = 1
        Me.txtContraseñaAntigua.UseSystemPasswordChar = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(91, 231)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 18)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Repita Contraseña"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(91, 171)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(147, 18)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Nueva Contraseña"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(91, 111)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(155, 18)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Contraseña Antigua"
        '
        'txtUsu
        '
        Me.txtUsu.Location = New System.Drawing.Point(317, 52)
        Me.txtUsu.Name = "txtUsu"
        Me.txtUsu.Size = New System.Drawing.Size(170, 20)
        Me.txtUsu.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(91, 52)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(152, 18)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Nombre de usuario"
        '
        'CamConLog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Honeydew
        Me.ClientSize = New System.Drawing.Size(591, 367)
        Me.Controls.Add(Me.txtUsu)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cb3)
        Me.Controls.Add(Me.cb2)
        Me.Controls.Add(Me.cb1)
        Me.Controls.Add(Me.btnBorrarCampos)
        Me.Controls.Add(Me.btnCambiarContraseña)
        Me.Controls.Add(Me.txtContraseñaNueva2)
        Me.Controls.Add(Me.txtContraseñaNueva1)
        Me.Controls.Add(Me.txtContraseñaAntigua)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "CamConLog"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CamConLog"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cb3 As System.Windows.Forms.CheckBox
    Friend WithEvents cb2 As System.Windows.Forms.CheckBox
    Friend WithEvents cb1 As System.Windows.Forms.CheckBox
    Friend WithEvents btnBorrarCampos As System.Windows.Forms.Button
    Friend WithEvents btnCambiarContraseña As System.Windows.Forms.Button
    Friend WithEvents txtContraseñaNueva2 As System.Windows.Forms.TextBox
    Friend WithEvents txtContraseñaNueva1 As System.Windows.Forms.TextBox
    Friend WithEvents txtContraseñaAntigua As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtUsu As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
