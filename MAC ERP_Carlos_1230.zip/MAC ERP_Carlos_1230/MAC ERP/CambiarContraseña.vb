﻿Public Class CambiarContraseña

    Private Sub cb1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb1.CheckedChanged
        cambConCheck(txtContraseñaAntigua)
    End Sub

    Private Sub cb2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb2.CheckedChanged
        cambConCheck(txtContraseñaNueva1)
    End Sub

    Private Sub cb3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb3.CheckedChanged
        cambConCheck(txtContraseñaNueva2)
    End Sub

    Private Sub btnBorrarCampos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrarCampos.Click
        Contra.borraCampos(txtContraseñaAntigua, txtContraseñaNueva1, txtContraseñaNueva2, cb1, cb2, cb3)
    End Sub

    Private Sub btnCambiarContraseña_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCambiarContraseña.Click
        Contra.cambContra(BD.consConex, txtContraseñaAntigua.Text, txtContraseñaNueva1.Text, txtContraseñaNueva2.Text)
    End Sub

    Private Sub CambiarContraseña_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class