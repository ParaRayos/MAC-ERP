﻿Public Class MenuEmpresa

    Private Sub btnAlmacen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAlmacen.Click
        PantallaProductos.Show()
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        desbloquearCampos()
        btnGuardar.Visible = True
    End Sub

    Public Sub desbloquearCampos()
        txtCif.ReadOnly = False
        txtNombre.ReadOnly = False
        txtLocalidad.ReadOnly = False
        txtProvincia.ReadOnly = False
        txtPais.ReadOnly = False
        txtCodPostal.ReadOnly = False
        txtSector.ReadOnly = False

        txtCif.BackColor = Color.White
        txtNombre.BackColor = Color.White
        txtLocalidad.BackColor = Color.White
        txtProvincia.BackColor = Color.White
        txtPais.BackColor = Color.White
        txtCodPostal.BackColor = Color.White
        txtSector.BackColor = Color.White
    End Sub

    Public Sub bloquearCampos()
        txtCif.ReadOnly = True
        txtNombre.ReadOnly = True
        txtLocalidad.ReadOnly = True
        txtProvincia.ReadOnly = True
        txtPais.ReadOnly = True
        txtCodPostal.ReadOnly = True
        txtSector.ReadOnly = True

        txtCif.BackColor = Color.Honeydew
        txtNombre.BackColor = Color.Honeydew
        txtLocalidad.BackColor = Color.Honeydew
        txtProvincia.BackColor = Color.Honeydew
        txtPais.BackColor = Color.Honeydew
        txtCodPostal.BackColor = Color.Honeydew
        txtSector.BackColor = Color.Honeydew
    End Sub

    Private Sub btnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGuardar.Click
        bloquearCampos()
        btnGuardar.Visible = False
    End Sub

    Private Sub MenuEmpresa_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class