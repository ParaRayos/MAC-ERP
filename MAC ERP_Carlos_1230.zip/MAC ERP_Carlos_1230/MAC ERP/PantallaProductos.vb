﻿Imports System.Data.OleDb

Public Class PantallaProductos
    Dim numeroSelecciones As Double
    Dim conexion As New OleDbConnection

    Private Sub btnAñadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAñadir.Click
        numeroSelecciones = DataGridView1.SelectedRows.Count
        If numeroSelecciones = 0 Then
            AñadirProducto.Show()
        Else
            MessageBox.Show("Tiene algún producto seleccionado. Quite la selección para poder añadir un nuevo producto.", "INFORMACION", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        numeroSelecciones = DataGridView1.SelectedRows.Count
        If numeroSelecciones = 1 Then
            MessageBox.Show("Se eliminarán el producto seleccionado. ¿Quiere continuar?.", "INFORMACION", MessageBoxButtons.OKCancel)
        ElseIf numeroSelecciones > 0 Then
            MessageBox.Show("Tiene más de un producto seleccionado.", "INFORMACION", MessageBoxButtons.OK)
        Else
            MessageBox.Show("No tiene ningún producto seleccionado", "INFORMACION", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        numeroSelecciones = DataGridView1.SelectedRows.Count
        If numeroSelecciones = 1 Then
            ModificarProducto.Show()
        ElseIf numeroSelecciones > 1 Then
            MessageBox.Show("Tiene más de un producto seleccionado.", "INFORMACION", MessageBoxButtons.OK)
        ElseIf numeroSelecciones = 0 Then
            MessageBox.Show("Seleccione algún producto para modificar.", "INFORMACION", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub PantallaProductos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cargarProductos()
    End Sub

    Public Sub cargarProductos()
        conexion.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=proyecto.accdb;Persist Security Info = True"
        conexion.Open()
        Dim tablaProductos As New DataTable
        Dim adapProductos As New OleDbDataAdapter
        Dim sql As String = "Select * from Productos"
        Dim comando As New OleDbCommand

        comando.Connection = conexion
        comando.CommandText = sql
        adapProductos.SelectCommand = comando
        adapProductos.Fill(tablaProductos)
        Me.DataGridView1.DataSource = tablaProductos
        comando.ExecuteNonQuery()
        comando.Dispose()
    End Sub
End Class